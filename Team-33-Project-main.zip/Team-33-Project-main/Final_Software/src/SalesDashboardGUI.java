import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class SalesDashboardGUI extends JPanel {

    private ApplicationFrame mainFrame;
    // Define color palette
    private static final Color COLOR_DARK_GRAY = new Color(50, 50, 50);
    private static final Color COLOR_LIGHT_GRAY = new Color(75, 75, 75);
    private static final Color COLOR_TEXT = Color.WHITE;

    private static JLabel todaysCostLabel;
    private static JLabel todaysSalesLabel;
    private static JLabel totalSalesLabel;

    private static JLabel favoriteDishesLabel;
    private JFormattedTextField startDateField, endDateField;
    private JPanel graphPanel;

    private static final Color BUTTON_LIGHT = new Color(180, 180, 180);

    private static final Color COLOR_BACKGROUND = new Color(42, 52, 54);
    private static final Color COLOR_WHITE = new Color(255, 255, 255);

    private JLabel graphTitle;

    private Map<String, Integer> monthlySalesData = getMonthlySalesData();
    private Map<String, Integer> yearlySalesData = getYearlySalesData();
    private static final Font titleFont = new Font("Helvetica", Font.BOLD, 18);
    private static final Font pageTitleFont = new Font("Helvetica", Font.BOLD, 25);

    private String graphState = "monthly";
    private String graphTitleState = "Monthly Bookings";
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");

    public SalesDashboardGUI(JFrame mainFrame) {

        this.mainFrame = (ApplicationFrame) mainFrame;
        setLayout(new BorderLayout());
        setSize(1200, 720);

        JPanel sidebar = createSidebar();
        add(sidebar, BorderLayout.WEST);

        JPanel contentArea = new JPanel(null);
        contentArea.setBackground(COLOR_BACKGROUND);

        JLabel pageNameLabel = new JLabel("Sales");
        pageNameLabel.setFont(pageTitleFont);
        pageNameLabel.setForeground(COLOR_TEXT);
        pageNameLabel.setBounds(465, 0, 200, 100);
        contentArea.add(pageNameLabel);

        JPanel todaysSalesCard = new JPanel();
        todaysSalesCard.setBounds(150, 100, 250, 100);
        todaysSalesCard.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(todaysSalesCard);
        todaysSalesLabel = createCard(null, null, todaysSalesCard);


        JPanel todaysCostPanel = new JPanel(); // Container for the card
        todaysCostPanel.setBounds(450, 100, 250, 100);
        todaysCostPanel.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(todaysCostPanel);
        todaysCostLabel = createCard(null, null, todaysCostPanel);


        JPanel totalSalesCard = new JPanel();
        totalSalesCard.setBounds(750, 100, 250, 100);
        totalSalesCard.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(totalSalesCard);
        totalSalesLabel = createCard(null, null, totalSalesCard);


        JPanel favoriteDishesCard = new JPanel();
        favoriteDishesCard.setLayout(new BorderLayout()); 
        favoriteDishesCard.setBounds(725, 250, 250, 300);
        favoriteDishesCard.setBackground(COLOR_LIGHT_GRAY);
        JLabel bestDishesLabel = new JLabel("BEST DISHES", SwingConstants.CENTER);
        bestDishesLabel.setForeground(COLOR_TEXT);
        bestDishesLabel.setFont(new Font("Helvetica", Font.BOLD, 16));
        bestDishesLabel.setBackground(COLOR_LIGHT_GRAY);
        bestDishesLabel.setOpaque(true);
        favoriteDishesCard.add(bestDishesLabel, BorderLayout.NORTH);
        favoriteDishesLabel = createCard(null, null, favoriteDishesCard );
        favoriteDishesCard.add(bestDishesLabel, BorderLayout.NORTH);
        contentArea.add(favoriteDishesCard, BorderLayout.NORTH);

        JPanel datePanel = createDatePanel();
        datePanel.setBounds(725, 570, 250, 100);
        datePanel.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(datePanel);


        graphTitle = new JLabel(graphTitleState, SwingConstants.CENTER);
        graphTitle.setFont(titleFont);
        graphTitle.setForeground(COLOR_TEXT);
        graphTitle.setBounds(30, 250, 800, 30);
        contentArea.add(graphTitle);
        graphPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (graphState == "monthly") {
                    drawBarChart(g, monthlySalesData, graphState);
                }
                else if (graphState == "yearly") {
                    drawBarChart(g, yearlySalesData, graphState);
                }
            }
        };

        graphPanel.setBounds(150, 245, 500, 380);
        graphPanel.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(graphPanel);

        JButton monthlyGraphButton = new JButton("Monthly Button");
        customizeButton(monthlyGraphButton);
        monthlyGraphButton.addActionListener(e -> {
            //System.out.println("Monthly Button");
            graphState = "monthly";
            graphTitleState = "Monthly Sales";
            graphTitle.setText(graphTitleState);
            monthlySalesData = getMonthlySalesData();
            //System.out.println(monthlyBookingsData);
            graphPanel.repaint();
            graphTitle.repaint();
        });

        monthlyGraphButton.setBounds(150, 640, 200, 35);
        monthlyGraphButton.setBackground(BUTTON_LIGHT);
        monthlyGraphButton.setFocusPainted(false);
        monthlyGraphButton.setBorderPainted(false);
        monthlyGraphButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                monthlyGraphButton.setBackground(COLOR_WHITE.brighter());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                monthlyGraphButton.setBackground(BUTTON_LIGHT);
            }
        });
        contentArea.add(monthlyGraphButton);

        JButton yearlyGraphButton = new JButton("Yearly Button");
        customizeButton(yearlyGraphButton);
        yearlyGraphButton.addActionListener(e -> {
            //System.out.println("Yearly Button");
            graphState = "yearly";
            graphTitleState = "Yearly Sales";
            graphTitle.setText(graphTitleState);
            yearlySalesData = getYearlySalesData();
            //System.out.println(yearlyBookingsData);
            graphPanel.repaint();
            graphTitle.repaint();
        });

        yearlyGraphButton.setBounds(450, 640, 200, 35);
        yearlyGraphButton.setBackground(BUTTON_LIGHT);
        yearlyGraphButton.setFocusPainted(false);
        yearlyGraphButton.setBorderPainted(false);
        yearlyGraphButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                yearlyGraphButton.setBackground(COLOR_WHITE.brighter());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                yearlyGraphButton.setBackground(BUTTON_LIGHT);
            }
        });
        contentArea.add(yearlyGraphButton);

        add(contentArea, BorderLayout.CENTER);
        calculateAndPrintTotalCost();
        calculateAndDisplayTotalSales();
        calculateTotalSalesOfAllTime();

    }

    private void drawBarChart(Graphics g, Map<String, Integer> data, String state) {
        int panelWidth = graphPanel.getWidth();
        int panelHeight = graphPanel.getHeight();

        Font numbersFont = new Font("Helvetica", Font.BOLD, 13); // Set a readable font size
        g.setFont(numbersFont);

        // Find the maximum count value for scaling bar heights
        int maxCount = Collections.max(data.values());

        // Calculate the y position for the bottom of the bars based on the panel height
        int yBottom = panelHeight - 50; // Leave some space at the bottom for labels

        // Y-axis position
        int yAxisX = 0; // You may adjust this value as needed
        int yAxisTop = 50; // Y position for the top of the Y-axis
        int yAxisBottom = panelHeight - 50; // Y position for the bottom of the Y-axis, matching the X-axis

        // Draw Y-axis line
        g.setColor(Color.WHITE);
        g.drawLine(yAxisX, yAxisTop, yAxisX, yAxisBottom);

        // Calculate the width of each bar and the spacing based on the panel width and number of data points
        int numberOfBars = data.size();
        int spacing = 10; // Adjust the spacing as needed
        int totalSpacing = (numberOfBars - 1) * spacing; // Total spacing between bars
        int barWidth = (panelWidth - totalSpacing) / numberOfBars;


        for (int i = 0; i < numberOfBars; i++) {
            String key = (String) data.keySet().toArray()[i];
            int count = data.get(key);

            // Scale the height of the bar to fit within the panel bounds
            int barHeight = (int) (((double) count / maxCount) * (panelHeight - 100)); // 100 pixels reserved for top and bottom margins

            // Set the x position for the current bar
            int x = i * (barWidth + spacing);

            // Draw the bar
            g.setColor(Color.WHITE); // Bar color
            g.fillRect(x, yBottom - barHeight, barWidth, barHeight);

            // Draw the value of the bar
            g.setColor(COLOR_DARK_GRAY); // Choose a color that contrasts with the bar's color
            String valueString = Integer.toString(count);
            int stringWidth = g.getFontMetrics().stringWidth(valueString);

            // Calculate the position of the string.
            // If the bar is not tall enough, draw the string above the bar instead.
            int stringY = yBottom - barHeight + g.getFontMetrics().getAscent();
            if (barHeight < g.getFontMetrics().getHeight() + 2) {
                stringY = yBottom - barHeight - g.getFontMetrics().getHeight();
                g.setColor(COLOR_DARK_GRAY); // Change the color to contrast with the background
            }

            int stringX = x + (barWidth / 2 - stringWidth / 2); // Center the string within the bar
            g.drawString(valueString, stringX, stringY);

            // Draw the label below the bar
            g.setColor(Color.WHITE);
            g.drawString(key, x + (barWidth / 2 - g.getFontMetrics().stringWidth(key) / 2), yBottom + 15); // Center the label below the bar
        }

        // Draw the axis line at the bottom
        g.setColor(Color.WHITE);
        g.drawLine(0, yBottom, panelWidth, yBottom);
    }

    private Map<String, Integer> getMonthlySalesData() {
        Map<String, Integer> monthlySalesMap = new LinkedHashMap<>();
        String query = "SELECT DATE_FORMAT(SaleDate, '%Y-%m') AS MonthYear, SUM(D.Price * DS.QuantitySold) AS SalesTotal " +
                "FROM DailySales DS " +
                "JOIN Dishes D ON DS.Dish_ID = D.Dish_ID " +
                "GROUP BY MonthYear " +
                "ORDER BY SaleDate ASC;";

        try (Connection conn = JDBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String monthYear = rs.getString("MonthYear");
                int total = rs.getInt("SalesTotal");
                monthlySalesMap.put(monthYear, total);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return monthlySalesMap;
    }

    private Map<String, Integer> getYearlySalesData() {
        Map<String, Integer> yearlySalesMap = new LinkedHashMap<>();
        String query = "SELECT YEAR(SaleDate) AS Year, SUM(D.Price * DS.QuantitySold) AS SalesTotal " +
                "FROM DailySales DS " +
                "JOIN Dishes D ON DS.Dish_ID = D.Dish_ID " +
                "GROUP BY Year " +
                "ORDER BY SaleDate ASC;";

        try (Connection conn = JDBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String year = rs.getString("Year");
                int total = rs.getInt("SalesTotal");
                yearlySalesMap.put(year, total);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return yearlySalesMap;
    }


    private JPanel createDatePanel() {
        JPanel datePanel = new JPanel();
        datePanel.setLayout(new BoxLayout(datePanel, BoxLayout.Y_AXIS));
        datePanel.setBackground(Color.BLACK);

        // Start Date components
        JPanel startDatePanel = new JPanel();
        startDatePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        startDatePanel.setBackground(COLOR_LIGHT_GRAY);
        JLabel startDateLabel = new JLabel("Start Date:");
        startDateLabel.setForeground(Color.WHITE);
        startDateField = new JFormattedTextField(dateFormat);
        startDateField.setColumns(10);
        startDatePanel.add(startDateLabel);
        startDatePanel.add(startDateField);

        // End Date components
        JPanel endDatePanel = new JPanel();
        endDatePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        endDatePanel.setBackground(COLOR_LIGHT_GRAY);
        JLabel endDateLabel = new JLabel("End Date:");
        endDateLabel.setForeground(Color.WHITE);
        endDateField = new JFormattedTextField(dateFormat);
        endDateField.setColumns(10);
        endDatePanel.add(endDateLabel);
        endDatePanel.add(endDateField);

        // Query Button
        JButton queryButton = new JButton("Query");
        customizeButton(queryButton);
        queryButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        queryButton.addActionListener(e -> calculateBestToWorstDishesFromDate(startDateField.getText(), endDateField.getText()));


        datePanel.add(startDatePanel);
        datePanel.add(endDatePanel);
        datePanel.add(queryButton);

        return datePanel;
    }


    public void calculateBestToWorstDishesFromDate(String startDate, String endDate) {
        try (Connection con = JDBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT D.Name, SUM(DS.QuantitySold) AS TotalSold " +
                             "FROM DailySales DS " +
                             "JOIN Dishes D ON DS.Dish_ID = D.Dish_ID " +
                             "WHERE DS.SaleDate BETWEEN '" + startDate + "' AND '" + endDate + "' " +
                             "GROUP BY DS.Dish_ID " +
                             "ORDER BY TotalSold DESC")) {

            StringBuilder result = new StringBuilder("<html><body style='text-align:left;'>");
            while (rs.next()) {
                result.append(String.format(
                        "<div style='margin:5px;'>" +
                                "<span style='font-weight:bold;color:#FFD700;'>%s:</span> " +
                                "<span style='color:white;'>%d sold</span>" +
                                "</div>",
                        rs.getString("Name"), rs.getInt("TotalSold")));
            }
            result.append("</body></html>");
            favoriteDishesLabel.setText(result.toString());
            favoriteDishesLabel.setVerticalAlignment(SwingConstants.TOP);
        } catch (SQLException e) {
            e.printStackTrace();
            favoriteDishesLabel.setText("Failed to calculate best-selling dish.");
        }
    }

    public void calculateTotalSalesOfAllTime() {
        try (Connection con = JDBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT SUM(D.Price * DS.QuantitySold) AS TotalSales " +
                             "FROM DailySales DS " +
                             "JOIN Dishes D ON DS.Dish_ID = D.Dish_ID")) {

            if (rs.next()) {
                double totalSales = rs.getDouble("TotalSales");
                SwingUtilities.invokeLater(() -> {
                    String htmlText = String.format(
                            "<html>" +
                                    "<div style='font-size:13px;font-family:Helvetica; font-weight:bold; text-align: center;color: white;'>Total Sales of All Time</div>" +
                                    "<div style='font-size:14px;font-family:Helvetica; font-weight:bold; text-align: center; color: white;'>£%.2f</div>" +
                                    "</html>", totalSales);
                    totalSalesLabel.setText(htmlText); // Assuming you want to display it in todaysSalesLabel
                });
            } else {
                SwingUtilities.invokeLater(() -> {
                    totalSalesLabel.setText("No sales data found.");
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> {
                totalSalesLabel.setText("Failed to calculate total sales.");
            });
        }
    }

    public void calculateAndDisplayTotalSales() {
        // Attempt to connect to the database and calculate total sales for the latest date
        try (Connection con = JDBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT DS.SaleDate, SUM(D.Price * DS.QuantitySold) AS TotalSales " +
                             "FROM DailySales DS " +
                             "JOIN Dishes D ON DS.Dish_ID = D.Dish_ID " +
                             "WHERE DS.SaleDate = (SELECT MAX(SaleDate) FROM DailySales) " +
                             "GROUP BY DS.SaleDate" )) {

            if (rs.next()) {
                double totalSales = rs.getDouble("TotalSales");
                String saleDate = rs.getString("SaleDate"); // Get the most recent sale date
                SwingUtilities.invokeLater(() -> {
                    String htmlText = String.format(
                            "<html>" +
                                    "<div style='font-size:13px;font-family:Helvetica; font-weight:bold; text-align: center;color: white;'>Total Sales for %s</div>" + // Title styling with date
                                    "<div style='font-size:14px;font-family:Helvetica; font-weight:bold; text-align: center; color: white;'>£%.2f</div>" + // Sales amount styling
                                    "</html>", saleDate, totalSales);
                    todaysSalesLabel.setText(htmlText);
                });
            } else {
                SwingUtilities.invokeLater(() -> {
                    todaysSalesLabel.setText("No sales data found.");
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> {
                todaysSalesLabel.setText("Failed to calculate total sales.");
            });
        }
    }
    public void calculateAndPrintTotalCost() {
        int orderId = findLatestOrderId();
        // Attempt to connect to the database, query the total cost, and print it
        try (Connection con = JDBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT SUM(i.Price * io.Quantity) AS TotalCost " +
                     "FROM IngredientOrders io " +
                     "JOIN Ingredient i ON io.Ingredient_ID = i.Ingredient_ID " +
                     "WHERE io.Order_ID = " + orderId)) {

            if (rs.next()) {
                double totalCost = rs.getDouble("TotalCost");
                SwingUtilities.invokeLater(() -> {
                    String htmlText = String.format(
                            "<html>" +
                                    "<div style='font-size:14px;font-family:Helvetica; font-weight:bold; text-align: center; color: white;'>Today's Cost</div>" + // Title styling
                                    "<div style='font-size:14px;font-family:Helvetica; font-weight:bold; text-align: center; color: white;'>£%.2f</div>" + // Price styling
                                    "</html>", totalCost);
                    todaysCostLabel.setText(htmlText);
                });
            } else {
                SwingUtilities.invokeLater(() -> {
                    todaysCostLabel.setText("No data found.");
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> {
                todaysCostLabel.setText("Failed to calculate cost");
            });
        }
    }

    private int findLatestOrderId() {
        try (Connection con = JDBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT MAX(Order_ID) AS LatestOrderID FROM Orders")) {
            if (rs.next()) {
                return rs.getInt("LatestOrderID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Return -1 if not found or an error occurs
    }

    private JLabel createCard(String title, String content, JPanel panelContainer) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(COLOR_LIGHT_GRAY);

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setForeground(COLOR_TEXT);
        card.add(titleLabel, BorderLayout.NORTH);

        JLabel contentLabel = new JLabel(content, SwingConstants.CENTER);
        contentLabel.setForeground(COLOR_TEXT);
        card.add(contentLabel, BorderLayout.CENTER);

        card.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panelContainer.add(card);
        return contentLabel;
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();

        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(COLOR_LIGHT_GRAY);

        try {
            BufferedImage logoImage = ImageIO.read(new File("images/logoRoot.png"));
            int diameter = 80; // Increase the diameter size of logo

            // Resize image
            Image scaledImage = logoImage.getScaledInstance(diameter, diameter, Image.SCALE_SMOOTH);
            BufferedImage resizedImage = new BufferedImage(diameter, diameter, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2dResized = resizedImage.createGraphics();
            g2dResized.drawImage(scaledImage, 0, 0, null);
            g2dResized.dispose();

            ImageIcon logoIcon = new ImageIcon(scaledImage);
            JLabel logoLabel = new JLabel(logoIcon);

            // Center the logo label horizontally in the sidebar
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebar.add(Box.createRigidArea(new Dimension(0, 15))); // offset from top of sidebar

            // Add logo label to sidebar
            sidebar.add(logoLabel);
            sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
            //sidebar.add(Box.createVerticalGlue());

            sidebar.add(createSidebarButton("Home"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20))); // Spacing between buttons
            sidebar.add(createSidebarButton("Bookings"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Review Menu"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Staff Tracking"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Sales"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Wine"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Order Ingredients"));

        }
        catch (Exception e) {
            System.out.println("Error fetching sidebar data: " + e.getMessage());
        }

        return sidebar;
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton("<html><center>" + text.replaceAll(" ", "<br>") + "</center></html>");

        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setPreferredSize(new Dimension(150, 75));
        button.setMaximumSize(new Dimension(150, button.getPreferredSize().height));
        button.setBackground(COLOR_DARK_GRAY);
        button.setForeground(COLOR_TEXT);
        button.setFocusPainted(false);
        button.setBorderPainted(false);

        // Change font and size of text in button:
        button.setFont(new Font("Helvetica", Font.BOLD, 16));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(COLOR_LIGHT_GRAY.brighter());
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(COLOR_DARK_GRAY);
            }
        });

        button.addActionListener(e -> {
            switch (text) {
                case "Home":
                    //System.out.println("Home button");
                    mainFrame.switchToMainMenu();
                    return;

                case "Bookings":
                    //System.out.println("Bookings button");
                    mainFrame.switchToBooking();
                    return;

                case "Review Menu":
                    //System.out.println("Review Menu button");
                    mainFrame.switchToReviewMenu();
                    return;

                case "Staff Tracking":
                    //System.out.println("Staff Tracking button");
                    mainFrame.switchToStaffTracking();
                    return;

                case "Sales":
                    //System.out.println("Sales button");
                    return;

                case "Wine":
                    //System.out.println("Wine button");
                    mainFrame.switchToWine();
                    return;

                case "Order Ingredients":
                    //System.out.println("Order Ingredients button");
                    mainFrame.switchToOrderIngredients();
                    return;
            }
        });

        return button;

    }

    private void customizeButton(JButton button) {
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFocusPainted(false);
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.repaint();
            }
        });
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                JButton b = (JButton) c;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (b.getModel().isRollover()) {
                    g2.setColor(new Color(115,116,124));
                } else {
                    g2.setColor(new Color(160,160,160));
                }
                g2.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), 30, 30);
                g2.dispose();
                super.paint(g, c);
            }
        });
    }

    public void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SalesDashboardGUI salesDashboardGUI = new SalesDashboardGUI(this.mainFrame);
            salesDashboardGUI.setVisible(true);
        });
    }
}