import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;


public class BookingGUI extends JPanel {

    private ApplicationFrame mainFrame;

    private static final Color COLOR_DARK_GRAY = new Color(50, 50, 50);
    private static final Color COLOR_LIGHT_GRAY = new Color(75, 75, 75);

    private static final Color BUTTON_LIGHT = new Color(180, 180, 180);

    private static final Color COLOR_BACKGROUND = new Color(42, 52, 54);
    private static final Color COLOR_WHITE = new Color(255, 255, 255);

    private static final Font titleFont = new Font("Helvetica", Font.BOLD, 18);
    private static final Font pageTitleFont = new Font("Helvetica", Font.BOLD, 25);

    private static final Color COLOR_TEXT = Color.WHITE;

    private static JLabel weeklyBookingsLabel;
    private static JLabel monthlyBookingsLabel;
    private static JLabel yearlyBookingsLabel;

    private JLabel graphTitle;
    private JPanel graphPanel;

    private Map<String, Integer> monthlyBookingsData = getMonthlyBookingsData();
    private Map<String, Integer> yearlyBookingsData = getYearlyBookingsData();

    private String graphState = "monthly";
    private String graphTitleState = "Monthly Bookings";

    public BookingGUI(JFrame mainFrame) {

        this.mainFrame = (ApplicationFrame) mainFrame;
        setLayout(new BorderLayout());
        setSize(1200, 720);

        JPanel sideBar = createSidebar();
        add(sideBar, BorderLayout.WEST);

        JPanel contentArea = new JPanel(null);
        contentArea.setBackground(COLOR_BACKGROUND);

        JLabel pageNameLabel = new JLabel("Bookings");
        pageNameLabel.setFont(pageTitleFont);
        pageNameLabel.setForeground(COLOR_TEXT);
        pageNameLabel.setBounds(465, 1, 200, 100);
        contentArea.add(pageNameLabel);

        JPanel weeklyBookingsCard = new JPanel();
        weeklyBookingsCard.setBounds(100, 100, 250, 100);
        weeklyBookingsCard.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(weeklyBookingsCard);
        weeklyBookingsLabel = createCard("Weekly Bookings:", weeklyBookingsCard.toString(), weeklyBookingsCard);

        JPanel monthlyBookingsCard = new JPanel();
        monthlyBookingsCard.setBounds(400, 100, 250, 100);
        monthlyBookingsCard.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(monthlyBookingsCard);
        monthlyBookingsLabel = createCard("Monthly Bookings:", null, monthlyBookingsCard);

        JPanel yearlyBookingsCard = new JPanel();
        yearlyBookingsCard.setBounds(700, 100, 250, 100);
        yearlyBookingsCard.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(yearlyBookingsCard);
        yearlyBookingsLabel = createCard("Yearly Bookings:", null, yearlyBookingsCard);

        graphTitle = new JLabel(graphTitleState, SwingConstants.CENTER);
        graphTitle.setFont(titleFont);
        graphTitle.setForeground(COLOR_TEXT);
        graphTitle.setBounds(100, 220, 800, 30);
        contentArea.add(graphTitle);

        graphPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (graphState == "monthly") {
                    drawBarChart(g, monthlyBookingsData, graphState);
                }
                else if (graphState == "yearly") {
                    drawBarChart(g, yearlyBookingsData, graphState);
                }
            }
        };
        graphPanel.setBounds(100, 250, 800, 350);
        graphPanel.setBackground(COLOR_BACKGROUND);
        contentArea.add(graphPanel);

        JButton monthlyGraphButton = new JButton("Monthly Button");
        customizeButton(monthlyGraphButton);
        monthlyGraphButton.addActionListener(e -> {
            //System.out.println("Monthly Button");
            graphState = "monthly";
            graphTitleState = "Monthly Bookings";
            graphTitle.setText(graphTitleState);
            monthlyBookingsData = getMonthlyBookingsData();
            //System.out.println(monthlyBookingsData);
            graphPanel.repaint();
            graphTitle.repaint();
        });

        monthlyGraphButton.setBounds(300, 620, 200, 35);
        monthlyGraphButton.setBackground(BUTTON_LIGHT);
        monthlyGraphButton.setFocusPainted(false);
        monthlyGraphButton.setBorderPainted(false);
        monthlyGraphButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                monthlyGraphButton.setBackground(COLOR_WHITE.brighter());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                monthlyGraphButton.setBackground(BUTTON_LIGHT);
            }
        });
        contentArea.add(monthlyGraphButton);

        JButton yearlyGraphButton = new JButton("Yearly Button");
        customizeButton(yearlyGraphButton);
        yearlyGraphButton.addActionListener(e -> {
            //System.out.println("Yearly Button");
            graphState = "yearly";
            graphTitleState = "Yearly Bookings";
            graphTitle.setText(graphTitleState);
            yearlyBookingsData = getYearlyBookingsData();
            //System.out.println(yearlyBookingsData);
            graphPanel.repaint();
            graphTitle.repaint();
        });

        yearlyGraphButton.setBounds(550, 620, 200, 35);
        yearlyGraphButton.setBackground(BUTTON_LIGHT);
        yearlyGraphButton.setFocusPainted(false);
        yearlyGraphButton.setBorderPainted(false);
        yearlyGraphButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                yearlyGraphButton.setBackground(COLOR_WHITE.brighter());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                yearlyGraphButton.setBackground(BUTTON_LIGHT);
            }
        });
        contentArea.add(yearlyGraphButton);

        add(contentArea, BorderLayout.CENTER);
        calculateWeeklyBookings();
        calculateMonthlyBookings();
        calculateYearlyBookings();

    }

    public void calculateWeeklyBookings() {
        String query = "SELECT COUNT(*) AS TotalBookings FROM Booking WHERE WEEK(BookingDate) = WEEK(NOW()) AND YEAR(BookingDate) = YEAR(NOW());";

        try (Connection conn = JDBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                int totalBookings = rs.getInt("TotalBookings");
                SwingUtilities.invokeLater(() -> weeklyBookingsLabel.setText(String.valueOf(totalBookings)));
            }
            else {
                SwingUtilities.invokeLater(() -> weeklyBookingsLabel.setText("No Bookings today."));
            }
        } catch (Exception e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> weeklyBookingsLabel.setText("Error fetching weekly data."));
        }
    }

    public void calculateMonthlyBookings() {
        String query = "SELECT COUNT(*) AS TotalBookings FROM Booking " +
                "WHERE MONTH(BookingDate) = MONTH(CURRENT_DATE()) AND YEAR(BookingDate) = YEAR(CURRENT_DATE());";

        try {
            Connection conn = JDBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            if (rs.next()) {
                int totalBookings = rs.getInt("TotalBookings");
                SwingUtilities.invokeLater(() -> monthlyBookingsLabel.setText(String.valueOf(totalBookings)));
            }
            else {
                SwingUtilities.invokeLater(() -> monthlyBookingsLabel.setText("No bookings for this month."));
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> monthlyBookingsLabel.setText("Error fetching monthly data."));
        }
    }

    public void calculateYearlyBookings() {
        String query = "SELECT COUNT(*) AS TotalBookings FROM Booking WHERE YEAR(BookingDate) = YEAR(CURDATE());";

        try {
            Connection conn = JDBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            if (rs.next()) {
                int totalBookings = rs.getInt("TotalBookings");
                SwingUtilities.invokeLater(() -> yearlyBookingsLabel.setText(String.valueOf(totalBookings)));
            }
            else {
                SwingUtilities.invokeLater(() -> yearlyBookingsLabel.setText("No bookings for this year."));
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> yearlyBookingsLabel.setText("Error fetching yearly data."));
        }
    }

    private Map<String, Integer> getMonthlyBookingsData() {
        Map<String, Integer> monthlyBookingsMap = new LinkedHashMap<>();
        String query = "SELECT MONTHNAME(BookingDate) AS Month, COUNT(*) AS BookingCount " +
                "FROM Booking " +
                "WHERE BookingDate >= NOW() - INTERVAL 1 YEAR " +
                "GROUP BY YEAR(BookingDate), MONTH(BookingDate) " +
                "ORDER BY BookingDate ASC;";

        try (Connection conn = JDBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String month = rs.getString("Month");
                int count = rs.getInt("BookingCount");
                monthlyBookingsMap.put(month, count);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //System.out.println(monthlyBookingsMap);
        return monthlyBookingsMap;
    }

    private Map<String, Integer> getYearlyBookingsData() {
        Map<String, Integer> yearlyBookingsMap = new LinkedHashMap<>();
        String query = "SELECT YEAR(BookingDate) AS Year, COUNT(*) AS BookingCount " +
                "FROM Booking " +
                "WHERE BookingDate >= NOW() - INTERVAL 4 YEAR " +
                "GROUP BY YEAR(BookingDate) " +
                "ORDER BY BookingDate ASC;";

        try (Connection conn = JDBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String year = String.valueOf(rs.getInt("Year"));
                int count = rs.getInt("BookingCount");
                yearlyBookingsMap.put(year, count);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //System.out.println(yearlyBookingsMap);
        return yearlyBookingsMap;
    }

    private JLabel createCard(String title, String content, JPanel panelContainer) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(COLOR_LIGHT_GRAY);

        // Create and style the title label
        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setForeground(COLOR_TEXT);
        titleLabel.setFont(new Font(titleLabel.getFont().getName(), Font.BOLD, 16)); // Set font size larger
        card.add(titleLabel, BorderLayout.NORTH);

        JLabel contentLabel = new JLabel(content, SwingConstants.CENTER);
        contentLabel.setForeground(COLOR_TEXT);
        contentLabel.setFont(new Font(contentLabel.getFont().getName(), Font.PLAIN, 36)); // Set font size larger
        card.add(contentLabel, BorderLayout.CENTER);

        card.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;

        card.add(titleLabel, gbc);
        gbc.gridy++;
        card.add(contentLabel, gbc);

        panelContainer.add(card);
        return contentLabel;
    }


    private void drawBarChart(Graphics g, Map<String, Integer> data, String state) {
        int panelWidth = graphPanel.getWidth();
        int panelHeight = graphPanel.getHeight();

        Font numbersFont = new Font("Helvetica", Font.BOLD, 13); // Set a readable font size
        g.setFont(numbersFont);

        // Find the maximum count value for scaling bar heights
        int maxCount = Collections.max(data.values());

        // Calculate the y position for the bottom of the bars based on the panel height
        int yBottom = panelHeight - 50; // Leave some space at the bottom for labels

        // Y-axis position
        int yAxisX = 0; // You may adjust this value as needed
        int yAxisTop = 50; // Y position for the top of the Y-axis
        int yAxisBottom = panelHeight - 50; // Y position for the bottom of the Y-axis, matching the X-axis

        // Draw Y-axis line
        g.setColor(Color.WHITE);
        g.drawLine(yAxisX, yAxisTop, yAxisX, yAxisBottom);

        // Calculate the width of each bar and the spacing based on the panel width and number of data points
        int numberOfBars = data.size();
        int spacing = 10;
        int totalSpacing = (numberOfBars - 1) * spacing; // Total spacing between bars
        int barWidth = (panelWidth - totalSpacing) / numberOfBars;


        for (int i = 0; i < numberOfBars; i++) {
            String key = (String) data.keySet().toArray()[i];
            int count = data.get(key);

            // Scale the height of the bar to fit within the panel bounds
            int barHeight = (int) (((double) count / maxCount) * (panelHeight - 100)); // 100 pixels reserved for top and bottom margins

            // Set the x position for the current bar
            int x = i * (barWidth + spacing);

            // Draw the bar
            g.setColor(Color.WHITE); // Bar color
            g.fillRect(x, yBottom - barHeight, barWidth, barHeight);

            // Draw the value of the bar
            g.setColor(COLOR_DARK_GRAY); // Choose a color that contrasts with the bar's color
            String valueString = Integer.toString(count);
            int stringWidth = g.getFontMetrics().stringWidth(valueString);

            // Calculate the position of the string.
            // If the bar is not tall enough, draw the string above the bar instead.
            int stringY = yBottom - barHeight + g.getFontMetrics().getAscent();
            if (barHeight < g.getFontMetrics().getHeight() + 2) {
                stringY = yBottom - barHeight - g.getFontMetrics().getHeight();
                g.setColor(COLOR_DARK_GRAY); // Change the color to contrast with the background
            }

            int stringX = x + (barWidth / 2 - stringWidth / 2); // Center the string within the bar
            g.drawString(valueString, stringX, stringY);

            // Draw the label below the bar
            g.setColor(Color.WHITE);
            g.drawString(key, x + (barWidth / 2 - g.getFontMetrics().stringWidth(key) / 2), yBottom + 15); // Center the label below the bar
        }

        // Draw the axis line at the bottom
        g.setColor(Color.WHITE);
        g.drawLine(0, yBottom, panelWidth, yBottom);
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();

        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(COLOR_LIGHT_GRAY);

        try {
            BufferedImage logoImage = ImageIO.read(new File("images/logoRoot.png"));
            int diameter = 80; // Increase the diameter size of logo

            // Resize image
            Image scaledImage = logoImage.getScaledInstance(diameter, diameter, Image.SCALE_SMOOTH);
            BufferedImage resizedImage = new BufferedImage(diameter, diameter, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2dResized = resizedImage.createGraphics();
            g2dResized.drawImage(scaledImage, 0, 0, null);
            g2dResized.dispose();

            ImageIcon logoIcon = new ImageIcon(scaledImage);
            JLabel logoLabel = new JLabel(logoIcon);

            // Center the logo label horizontally in the sidebar
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebar.add(Box.createRigidArea(new Dimension(0, 15))); // offset from top of sidebar

            // Add logo label to sidebar
            sidebar.add(logoLabel);
            sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
            //sidebar.add(Box.createVerticalGlue());


            sidebar.add(createSidebarButton("Home"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20))); // Spacing between buttons
            sidebar.add(createSidebarButton("Bookings"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Review Menu"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Staff Tracking"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Sales"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Wine"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Order Ingredients"));

        }
        catch (Exception e) {
            System.out.println("Error fetching sidebar data: " + e.getMessage());
        }

        return sidebar;
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton("<html><center>" + text.replaceAll(" ", "<br>") + "</center></html>");

        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setPreferredSize(new Dimension(150, 75));
        button.setMaximumSize(new Dimension(150, button.getPreferredSize().height));
        button.setBackground(COLOR_DARK_GRAY);
        button.setForeground(COLOR_TEXT);
        button.setFocusPainted(false);
        button.setBorderPainted(false);

        // Change font and size of text in button:
        button.setFont(new Font("Helvetica", Font.BOLD, 16));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(COLOR_LIGHT_GRAY.brighter());
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(COLOR_DARK_GRAY);
            }
        });

        button.addActionListener(e -> {
            switch (text) {
                case "Home":
                    //System.out.println("Home button");
                    mainFrame.switchToMainMenu();
                    return;

                case "Bookings":
                    //System.out.println("Bookings button");
                    return;

                case "Review Menu":
                    //System.out.println("Review Menu button");
                    mainFrame.switchToReviewMenu();
                    return;

                case "Staff Tracking":
                    //System.out.println("Staff Tracking button");
                    mainFrame.switchToStaffTracking();
                    return;

                case "Sales":
                    //System.out.println("Sales button");
                    mainFrame.switchToSales();
                    return;

                case "Wine":
                    //System.out.println("Wine button");
                    mainFrame.switchToWine();
                    return;

                case "Order Ingredients":
                    //System.out.println("Order Ingredients button");
                    mainFrame.switchToOrderIngredients();
                    return;
            }
        });

        return button;

    }

    private void customizeButton(JButton button) {
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFocusPainted(false);
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.repaint();
            }
        });
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                JButton b = (JButton) c;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (b.getModel().isRollover()) {
                    g2.setColor(new Color(115,116,124));
                } else {
                    g2.setColor(new Color(160,160,160));
                }
                g2.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), 30, 30);
                g2.dispose();
                super.paint(g, c);
            }
        });
    }

    public void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            BookingGUI bookingGUI = new BookingGUI(this.mainFrame);
            bookingGUI.setVisible(true);
        });
    }
}
