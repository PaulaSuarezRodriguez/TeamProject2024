import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class LoginGUI extends JPanel {

    private ApplicationFrame mainFrame;

    private RoundedTextField emailField;
    private RoundedPasswordField passwordField;
    Color greyL = new Color(42,52,54);
    Color greyLlight = new Color(115,124,124);

    private static final Color COLOR_DARK_GRAY = new Color(50, 50, 50);
    private static final Color COLOR_LIGHT_GRAY = new Color(75, 75, 75);

    private static final Color BUTTON_LIGHT = new Color(180, 180, 180);

    private static final Color COLOR_BACKGROUND = new Color(42, 52, 54);
    private static final Color COLOR_WHITE = new Color(255, 255, 255);

    private static final Font titleFont = new Font("Helvetica", Font.BOLD, 18);
    private static final Font pageTitleFont = new Font("Helvetica", Font.BOLD, 35);
    private static final Font textFont = new Font("Helvetica", Font.BOLD, 16);

    private static final Color COLOR_TEXT = Color.WHITE;


    public LoginGUI(JFrame mainFrame) {

        this.mainFrame = (ApplicationFrame) mainFrame;
        setLayout(new BorderLayout());
        setSize(1200, 720);

        // Logo panel at the top
        JPanel logoPanel = new JPanel();
        logoPanel.setPreferredSize(new Dimension(200, 200));
        logoPanel.add(new JLabel(new ImageIcon(loadImage("src/lancasterLogo.png", 200, 200))));
        add(logoPanel, BorderLayout.NORTH);
        logoPanel.setBackground(COLOR_BACKGROUND);

        JLabel pageNameLabel = new JLabel("Login");
        pageNameLabel.setFont(pageTitleFont);
        pageNameLabel.setForeground(COLOR_TEXT);
        pageNameLabel.setBounds(545, 200, 200, 100);
        add(pageNameLabel, BorderLayout.CENTER);

        // Input fields panel with GridBagLayout for better control
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(textFont);
        usernameLabel.setForeground(COLOR_TEXT);
        usernameLabel.setBounds(550, 250, 200, 100);
        add(usernameLabel, BorderLayout.CENTER);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(textFont);
        passwordLabel.setForeground(COLOR_TEXT);
        passwordLabel.setBounds(550, 310, 200, 100);
        add(passwordLabel, BorderLayout.CENTER);

        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBackground(COLOR_BACKGROUND);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(30, 30, 10, 30);

        emailField = new RoundedTextField(30);
        emailField.setHorizontalAlignment(JTextField.CENTER);
        emailField.setPlaceholder("EMAIL");
        setupPlaceholder(emailField, "EMAIL");
        inputPanel.add(emailField, gbc);

        passwordField = new RoundedPasswordField(30);
        passwordField.setPlaceholder("PASSWORD");
        passwordField.setHorizontalAlignment(JTextField.CENTER);
        setupPlaceholder(passwordField, "PASSWORD");
        inputPanel.add(passwordField, gbc);

        // Login Button
        JButton loginButton = new JButton("Login");
        customizeButtonLogin(loginButton);
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkCredentials(emailField.getText(), new String(passwordField.getPassword()))) {
                    ((ApplicationFrame) mainFrame).switchToMainMenu();
                }
                else {
                    JOptionPane.showMessageDialog(LoginGUI.this, "Invalid credentials!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        inputPanel.add(loginButton, gbc);

        // Forgot Password Link
        JButton newUserButton = new JButton("New user?");
        newUserButton.setBorderPainted(false);
        newUserButton.setOpaque(false);
        newUserButton.setBackground(Color.WHITE);
        newUserButton.setForeground(Color.WHITE);
        newUserButton.addActionListener(e -> {
            ((ApplicationFrame) mainFrame).switchToNewUser();
        });
        inputPanel.add(newUserButton, gbc);

        add(inputPanel, BorderLayout.CENTER);

        // Bottom panel
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(greyLlight);
        bottomPanel.setPreferredSize(new Dimension(100, 50));
        bottomPanel.add(new JLabel(new ImageIcon(loadImage("src/logoRoot.png", 50, 50))), BorderLayout.WEST);
        bottomPanel.add(new JSeparator(), BorderLayout.CENTER);
        JLabel copyrightLabel = new JLabel("© 2023 Root Solutions");
        bottomPanel.add(copyrightLabel, BorderLayout.EAST);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private Image loadImage(String path, int width, int height) {
        BufferedImage resizedImage = null;
        try {
            BufferedImage originalImage = ImageIO.read(new File(path));
            resizedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = resizedImage.createGraphics();
            g2d.drawImage(originalImage, 0, 0, width, height, null);
            g2d.dispose();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resizedImage;
    }

    private void setupPlaceholder(JTextField field, String text) {
        field.setForeground(Color.GRAY);
        field.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (field.getText().equals(text)) {
                    field.setText("");
                    field.setForeground(Color.BLACK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent evt) {
                if (field.getText().isEmpty()) {
                    field.setForeground(Color.GRAY);
                    field.setText(text);
                }
            }
        });
    }

    private boolean checkCredentials(String email, String password) {
        String query = "SELECT * FROM Login WHERE Username=? AND Password=?";
        boolean hasCredential = false;
        try (Connection conn = JDBConnection.getConnection();

            PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, email);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                hasCredential = rs.next();
            }

        }
        catch (Exception e) {
            System.out.println("Error checking credentials: " + e.getMessage());
        }

        return hasCredential;
    }

    private void customizeButtonLogin(JButton button) {
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFocusPainted(false);
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.repaint();
            }
        });
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                JButton b = (JButton) c;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (b.getModel().isRollover()) {
                    g2.setColor(new Color(115,116,124));
                } else {
                    g2.setColor(new Color(160,160,160));
                }
                g2.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), 30, 30);
                g2.dispose();
                super.paint(g, c);
            }
        });
    }
    public void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginGUI loginGUI = new LoginGUI(this.mainFrame);
            loginGUI.setVisible(true);
        });
    }
}

// Custom rounded text field
class RoundedTextField extends JTextField {
    private Shape shape;
    private String placeholder;

    public RoundedTextField(int size) {
        super(size);
        setOpaque(false); // As per your design
    }

    protected void paintComponent(Graphics g) {
        g.setColor(getBackground());
        g.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 15, 15);
        super.paintComponent(g);
    }

    protected void paintBorder(Graphics g) {
        g.setColor(getForeground());
        g.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 15, 15);
    }

    public boolean contains(int x, int y) {
        if (shape == null || !shape.getBounds().equals(getBounds())) {
            shape = new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 15, 15);
        }
        return shape.contains(x, y);
    }

    public void setPlaceholder(String text) {
        this.placeholder = text;
    }
}

// Custom rounded password field
class RoundedPasswordField extends JPasswordField {
    private Shape shape;
    private String placeholder;

    public RoundedPasswordField(int size) {
        super(size);
        setOpaque(false); // As per your design
    }

    protected void paintComponent(Graphics g) {
        g.setColor(getBackground());
        g.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 15, 15);
        super.paintComponent(g);
    }

    protected void paintBorder(Graphics g) {
        g.setColor(getForeground());
        g.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 15, 15);
    }

    public boolean contains(int x, int y) {
        if (shape == null || !shape.getBounds().equals(getBounds())) {
            shape = new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 15, 15);
        }
        return shape.contains(x, y);
    }

    public void setPlaceholder(String text) {
        this.placeholder = text;
    }
}
