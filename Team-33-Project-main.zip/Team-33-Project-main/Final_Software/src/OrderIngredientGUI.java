import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import java.util.Date;


public class OrderIngredientGUI extends JPanel {

    private ApplicationFrame mainFrame;

    private JComboBox<String> ingredientComboBox;

    private JTable orderTable;
    private DefaultTableModel tableModel;
    private JTextField quantityField;
    private JButton orderButton, deleteButton;
    private List<Ingredient> ingredients;

    private static final Color COLOR_DARK_GRAY = new Color(50, 50, 50);
    private static final Color COLOR_LIGHT_GRAY = new Color(75, 75, 75);
    private static final Color COLOR_BACKGROUND = new Color(42, 52, 54);
    private static final Color COLOR_WHITE = new Color(255, 255, 255);
    private static final Color COLOR_TEXT = Color.WHITE;
    private static final Font pageTitleFont = new Font("Helvetica", Font.BOLD, 25);

    JPanel contentArea = new JPanel(null);

    public OrderIngredientGUI(JFrame mainFrame) {

        //setTitle("Ingredient Ordering");
        this.mainFrame = (ApplicationFrame) mainFrame;
        setLayout(new BorderLayout());
        setSize(1200, 720);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel sidebar = createSidebar();
        add(sidebar, BorderLayout.WEST);

        contentArea = new JPanel(null);
        contentArea.setBackground(COLOR_BACKGROUND);

        JLabel pageNameLabel = new JLabel("Order Ingredients");
        pageNameLabel.setFont(pageTitleFont);
        pageNameLabel.setForeground(COLOR_TEXT);
        pageNameLabel.setBounds(465, 0, 250, 100);
        contentArea.add(pageNameLabel);

        JPanel area = new JPanel();
        area.setLayout(null);
        area.setBackground(COLOR_LIGHT_GRAY);
        area.setBounds(400, 450, 300, 200);
        contentArea.add(area);

        JLabel ingredientLabel = new JLabel("Select Ingredient:");
        ingredientLabel.setForeground(COLOR_TEXT);
        ingredientLabel.setBounds(50, 20, 200, 25);
        area.add(ingredientLabel);

        ingredientComboBox = new JComboBox<>();
        ingredientComboBox.setBounds(50, 50, 200, 25);
        area.add(ingredientComboBox);

        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setForeground(COLOR_TEXT);
        quantityLabel.setBounds(50, 80, 200, 25);
        area.add(quantityLabel);

        quantityField = new JTextField();
        quantityField.setBounds(50, 110, 200, 25);
        area.add(quantityField);

        orderButton = new JButton("Place Order");
        customizeButton(orderButton);
        orderButton.setBounds(50, 140, 200, 25);
        orderButton.setBackground(COLOR_LIGHT_GRAY);
        orderButton.setForeground(COLOR_TEXT);
        area.add(orderButton);
        orderButton.addActionListener(e -> {
            placeOrder();

        });

        deleteButton = new JButton("Delete Selected");
        customizeButton(deleteButton);
        deleteButton.setBounds(50, 170, 200, 25);
        deleteButton.setBackground(COLOR_LIGHT_GRAY);
        deleteButton.setForeground(COLOR_TEXT);
        area.add(deleteButton);
        deleteButton.addActionListener(e -> deleteSelectedOrder());

        add(contentArea);
        setupOrderTable();
        fetchIngredients();
    }


    private void deleteSelectedOrder() {
        int selectedRow = orderTable.getSelectedRow();
        if (selectedRow >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete the selected order item?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                int orderId = (int) tableModel.getValueAt(selectedRow, 0);
                int ingredientId = ingredients.stream()
                        .filter(ing -> ing.getName().equals(tableModel.getValueAt(selectedRow, 1)))
                        .findFirst()
                        .orElse(new Ingredient(-1, "", 0.0))
                        .getId();
                deleteOrderItem(orderId, ingredientId);
                tableModel.removeRow(selectedRow);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select an order to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void deleteOrderItem(int orderId, int ingredientId) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = JDBConnection.getConnection();
            conn.setAutoCommit(false);

            String sql = "DELETE FROM IngredientOrders WHERE Order_ID = ? AND Ingredient_ID = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, orderId);
            pstmt.setInt(2, ingredientId);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(this, "Order item deleted successfully!");
                conn.commit();
            } else {
                conn.rollback();
                JOptionPane.showMessageDialog(this, "No order item found with the specified details.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            JOptionPane.showMessageDialog(this, "Error deleting order item: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            JDBConnection.closeStatement(pstmt);
            JDBConnection.closeConnection(conn);
        }
    }
    private void setupOrderTable() {
        // Define the column names for the table
        String[] columnNames = {"Order ID", "Ingredient", "Quantity", "Date Placed"};

        tableModel = new DefaultTableModel(columnNames, 0);
        orderTable = new JTable(tableModel);

        orderTable.setFillsViewportHeight(true);

        JScrollPane scrollPane = new JScrollPane(orderTable);
        scrollPane.setBounds(210, 100, 700, 300);
        contentArea.add(scrollPane);
    }

    private void updateOrderTable(int orderId, String ingredientName, int quantity) {
        // Add a new row to the table model
        String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        tableModel.addRow(new Object[]{orderId, ingredientName, quantity, today});
    }
    private void fetchIngredients() {
        ingredients = new ArrayList<>();
        try (Connection conn = JDBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Ingredient")) {
            while (rs.next()) {
                ingredients.add(new Ingredient(
                        rs.getInt("Ingredient_ID"),
                        rs.getString("Name"),
                        rs.getDouble("Price")));
                ingredientComboBox.addItem(rs.getString("Name"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching ingredients: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void placeOrder() {
        if (ingredientComboBox.getSelectedIndex() == -1 || quantityField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select an ingredient and specify a quantity.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int ingredientId = ingredients.get(ingredientComboBox.getSelectedIndex()).getId();
        String ingredientName = ingredients.get(ingredientComboBox.getSelectedIndex()).getName();
        int quantity;
        try {
            quantity = Integer.parseInt(quantityField.getText());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid quantity.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int orderId = findOrCreateTodayOrder();
            System.out.println("Order ID: " + orderId);  // Debugging output
            try (Connection conn = JDBConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement("INSERT INTO IngredientOrders (Order_ID, Ingredient_ID, Quantity) VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setInt(1, orderId);
                pstmt.setInt(2, ingredientId);
                pstmt.setInt(3, quantity);
                int affectedRows = pstmt.executeUpdate();

                if (affectedRows > 0) {
                    updateOrderTable(orderId, ingredientName, quantity);
                    JOptionPane.showMessageDialog(this, "Order placed successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "No rows updated, check SQL and data integrity.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error placing order: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private int findOrCreateTodayOrder() throws SQLException {
        // Check if an order exists for today
        String checkSql = "SELECT Order_ID FROM Orders WHERE OrderDate = CURDATE();";
        try (Connection conn = JDBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(checkSql)) {
            if (rs.next()) {
                return rs.getInt("Order_ID");
            } else {
                // If no order exists for today, create a new one
                return createNewOrder();
            }
        }
    }

    private int createNewOrder() throws SQLException {
        String sql = "INSERT INTO Orders (OrderDate) VALUES (CURDATE());";
        try (Connection conn = JDBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.executeUpdate();
            try (ResultSet rs = pstmt.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1);
                } else {
                    throw new SQLException("Creating order failed, no ID obtained.");
                }
            }
        }
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();

        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(COLOR_LIGHT_GRAY);

        try {
            BufferedImage logoImage = ImageIO.read(new File("images/logoRoot.png"));
            int diameter = 80; // Increase the diameter size of logo

            // Resize image
            Image scaledImage = logoImage.getScaledInstance(diameter, diameter, Image.SCALE_SMOOTH);
            BufferedImage resizedImage = new BufferedImage(diameter, diameter, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2dResized = resizedImage.createGraphics();
            g2dResized.drawImage(scaledImage, 0, 0, null);
            g2dResized.dispose();

            ImageIcon logoIcon = new ImageIcon(scaledImage);
            JLabel logoLabel = new JLabel(logoIcon);

            // Center the logo label horizontally in the sidebar
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebar.add(Box.createRigidArea(new Dimension(0, 15))); // offset from top of sidebar

            // Add logo label to sidebar
            sidebar.add(logoLabel);
            sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
            //sidebar.add(Box.createVerticalGlue());

            sidebar.add(createSidebarButton("Home"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20))); // Spacing between buttons
            sidebar.add(createSidebarButton("Bookings"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Review Menu"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Staff Tracking"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Sales"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Wine"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Order Ingredients"));

        }
        catch (Exception e) {
            System.out.println("Error fetching sidebar data: " + e.getMessage());
        }

        return sidebar;
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton("<html><center>" + text.replaceAll(" ", "<br>") + "</center></html>");

        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setPreferredSize(new Dimension(150, 75));
        button.setMaximumSize(new Dimension(150, button.getPreferredSize().height));
        button.setBackground(COLOR_DARK_GRAY);
        button.setForeground(COLOR_TEXT);
        button.setFocusPainted(false);
        button.setBorderPainted(false);

        // Change font and size of text in button:
        button.setFont(new Font("Helvetica", Font.BOLD, 16));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(COLOR_LIGHT_GRAY.brighter());
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(COLOR_DARK_GRAY);
            }
        });

        button.addActionListener(e -> {
            switch (text) {
                case "Home":
                    //System.out.println("Home button");
                    mainFrame.switchToMainMenu();
                    return;

                case "Bookings":
                    //System.out.println("Bookings button");
                    mainFrame.switchToBooking();
                    return;

                case "Review Menu":
                    //System.out.println("Review Menu button");
                    mainFrame.switchToReviewMenu();
                    return;

                case "Staff Tracking":
                    //System.out.println("Staff Tracking button");
                    mainFrame.switchToStaffTracking();
                    return;

                case "Sales":
                    //System.out.println("Sales button");
                    mainFrame.switchToSales();
                    return;

                case "Wine":
                    //System.out.println("Wine button");
                    mainFrame.switchToWine();
                    return;

                case "Order Ingredients":
                    //System.out.println("Order Ingredients button");
                    return;
            }
        });

        return button;

    }

    private void customizeButton(JButton button) {
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFocusPainted(false);
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.repaint();
            }
        });
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                JButton b = (JButton) c;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (b.getModel().isRollover()) {
                    g2.setColor(new Color(115,116,124));
                } else {
                    g2.setColor(new Color(160,160,160));
                }
                g2.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), 30, 30);
                g2.dispose();
                super.paint(g, c);
            }
        });
    }

    public void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            OrderIngredientGUI dashboard = new OrderIngredientGUI(this.mainFrame);
            dashboard.setVisible(true);
        });
    }
}

class Ingredient {
    private int id;
    private String name;
    private double price;

    public Ingredient(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
}
