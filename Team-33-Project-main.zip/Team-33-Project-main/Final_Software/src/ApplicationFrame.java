import javax.swing.*;

public class ApplicationFrame extends JFrame {

    public ApplicationFrame() {
        setTitle("Lancaster System");
        setSize(1200, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ImageIcon image = new ImageIcon("src/logoRoot.png");
        setIconImage(image.getImage());

        login();
    }

    public void login() {
        LoginGUI loginPanel = new LoginGUI(this);
        setContentPane(loginPanel);
        revalidate();
        repaint();
    }

    public void switchToNewUser() {
        NewUserGUI newUserPanel = new NewUserGUI(this);
        setContentPane(newUserPanel);
        revalidate();
        repaint();
    }

    public void switchToMainMenu() {
        MainMenuGUI mainMenuPanel = new MainMenuGUI(this);
        setContentPane(mainMenuPanel);
        revalidate();
        repaint();
    }

    public void switchToBooking() {
        BookingGUI bookingPanel = new BookingGUI(this);
        setContentPane(bookingPanel);
        revalidate();
        repaint();
    }

    public void switchToReviewMenu() {
        ReviewMenuGUI reviewMenuPanel = new ReviewMenuGUI(this);
        setContentPane(reviewMenuPanel);
        revalidate();
        repaint();
    }

    public void switchToStaffTracking() {
        StaffTrackingGUI staffTrackingPanel = new StaffTrackingGUI(this);
        setContentPane(staffTrackingPanel);
        revalidate();
        repaint();
    }

    public void switchToSales() {
        SalesDashboardGUI salesDashboardPanel = new SalesDashboardGUI(this);
        setContentPane(salesDashboardPanel);
        revalidate();
        repaint();
    }

    public void switchToWine() {
        WineGUI winePanel = new WineGUI(this);
        setContentPane(winePanel);
        revalidate();
        repaint();
    }

    public void switchToOrderIngredients() {
        OrderIngredientGUI orderIngredientPanel = new OrderIngredientGUI(this);
        setContentPane(orderIngredientPanel);
        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ApplicationFrame appFrame = new ApplicationFrame();
            appFrame.setVisible(true);
        });
    }
}
