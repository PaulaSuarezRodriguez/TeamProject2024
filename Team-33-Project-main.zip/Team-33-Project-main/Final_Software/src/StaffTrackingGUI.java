import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

public class StaffTrackingGUI extends JPanel {

    private ApplicationFrame mainFrame;


    // Define color palette
    private static final Color COLOR_DARK_GRAY = new Color(50, 50, 50);
    private static final Color COLOR_LIGHT_GRAY = new Color(75, 75, 75);
    private static final Color BUTTON_LIGHT = new Color(180, 180, 180);
    private static final Color COLOR_WHITE = new Color(255, 255, 255);
    private static final Color COLOR_TEXT = Color.WHITE;
    private static final Color COLOR_BACKGROUND = new Color(42, 52, 54);

    private static final Font titleFont = new Font("Helvetica", Font.BOLD, 18);
    private static final Font pageTitleFont = new Font("Helvetica", Font.BOLD, 25);


    private static JLabel totalStaffWorkingLabel, totalStaffOnHolidayLabel, periodHolidayLabel;

    private DefaultTableModel tableModel, tableModel2;
    private JTable staffAvailableTable, staffOnHolidayTable;
    private JFormattedTextField startDateField, endDateField;

    LocalDate currentDate = LocalDate.now();
    String holidayStartDate, holidayEndDate;
    String currentDateString = currentDate.toString();
    JPanel contentArea;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public StaffTrackingGUI(JFrame mainFrame) {

        this.mainFrame = (ApplicationFrame) mainFrame;
        setLayout(new BorderLayout());
        setSize(1200, 720);

        JPanel sidebar = createSidebar();
        add(sidebar, BorderLayout.WEST);

        // Create and add content area
        contentArea = new JPanel(null); // Set layout to null
        //contentArea.setBounds(0, 0, 1200, 720); // Set bounds for the content area
        contentArea.setBackground(COLOR_BACKGROUND);

        // Create a label for staffAvailableTable
        JLabel staffAvailableTableLabel = new JLabel("List of available staff members today:");
        staffAvailableTableLabel.setForeground(Color.WHITE);
        staffAvailableTableLabel.setFont(new Font("Helvetica", Font.BOLD, 18));
        staffAvailableTableLabel.setBounds(100, 0, 550, 30); // Adjust the bounds as needed
        contentArea.add(staffAvailableTableLabel);

        // Create table staffAvailableTable
        tableModel = new DefaultTableModel(new String[]{"StaffID", "Name", "Role"}, 0);
        staffAvailableTable = new JTable(tableModel);
        staffAvailableTable.setBounds(100, 30, 550, 250); // Set bounds for the table
        staffAvailableTable.setBackground(COLOR_WHITE);
        staffAvailableTable.setForeground(Color.BLACK);
        staffAvailableTable.setFont(new Font("Helvetica", Font.PLAIN, 16));
        JScrollPane scrollPane = new JScrollPane(staffAvailableTable);
        scrollPane.setBounds(100, 30, 550, 250); // Set bounds for the scroll pane
        scrollPane.getViewport().setBackground(COLOR_WHITE);
        contentArea.add(scrollPane);

        // Create a label for staffOnHolidayTable
        JLabel staffOnHolidayTableLabel = new JLabel("List of staff members on holiday today:");
        staffOnHolidayTableLabel.setForeground(Color.WHITE);
        staffOnHolidayTableLabel.setFont(new Font("Helvetica", Font.BOLD, 18));
        staffOnHolidayTableLabel.setBounds(100, 350, 550, 30); // Adjust the bounds as needed
        contentArea.add(staffOnHolidayTableLabel);

        // Create table staffOnHolidayTable
        tableModel2 = new DefaultTableModel(new String[]{"StaffID", "Name", "Role"}, 0);
        staffOnHolidayTable = new JTable(tableModel2);
        staffOnHolidayTable.setBounds(100, 380, 550, 250); // Set bounds for the panel
        staffOnHolidayTable.setBackground(COLOR_WHITE);
        staffOnHolidayTable.setForeground(Color.BLACK);
        staffOnHolidayTable.setFont(new Font("Helvetica", Font.PLAIN, 16));
        JScrollPane scrollPane2 = new JScrollPane(staffOnHolidayTable);
        scrollPane2.setBounds(100, 380, 550, 250); // Set bounds for the scroll pane
        scrollPane2.getViewport().setBackground(COLOR_WHITE);
        contentArea.add(scrollPane2);

        //Buttons FIRST table
        addStaffButtonMethod(100, 290, 155, 35, staffAvailableTable);
        deleteStaffButtonMethod(300, 290, 155, 35, staffAvailableTable);
        updateStaffButtonMethod(500, 290, 155, 35, staffAvailableTable);

        //Buttons SECOND table
        addStaffButtonMethod(100, 640, 155, 35, staffOnHolidayTable);
        deleteStaffButtonMethod(300, 640, 155, 35, staffOnHolidayTable);
        updateStaffButtonMethod(500, 640, 155, 35, staffOnHolidayTable);

        //Period holiday result box and text
        JPanel periodHolidayPanel = new JPanel();
        periodHolidayPanel.setBounds(700, 30, 300, 375);
        periodHolidayPanel.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(periodHolidayPanel);
        periodHolidayLabel = createCard("<html>Staff on holiday over the<br>period of time specified:</html>", null, periodHolidayPanel);

        //Date panel
        JPanel datePanel = createDatePanel();
        datePanel.setBounds(700, 420, 300, 120);
        datePanel.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(datePanel);

        // Total staff working
        JPanel totalStaffWorkingPanel = new JPanel();
        totalStaffWorkingPanel.setBounds(700, 550, 130, 90); // Set bounds for the panel
        totalStaffWorkingPanel.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(totalStaffWorkingPanel);
        totalStaffWorkingLabel = createCard("Staff working today:", null, totalStaffWorkingPanel);

        // Total staff on holiday
        JPanel totalStaffOnHolidayPanel = new JPanel();
        totalStaffOnHolidayPanel.setBounds(870, 550, 130, 90); // Set bounds for the panel
        totalStaffOnHolidayPanel.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(totalStaffOnHolidayPanel);
        totalStaffOnHolidayLabel = createCard("Staff on holiday:", null, totalStaffOnHolidayPanel);

        add(contentArea);

        calculateTotalStaffWorking(currentDateString, holidayStartDate, holidayEndDate);
        calculateTotalStaffOnHoliday(currentDateString, holidayStartDate, holidayEndDate);

        todaysAvailableStaff(currentDateString, holidayStartDate, holidayEndDate);
        todaysOnHolidayStaff(currentDateString, holidayStartDate, holidayEndDate);

    }

    private JPanel createDatePanel() {
        JPanel datePanel = new JPanel();
        datePanel.setLayout(new BoxLayout(datePanel, BoxLayout.Y_AXIS));

        // Start Date components
        JPanel startDatePanel = new JPanel();
        startDatePanel.setBounds(740, 660, 300, 100);
        startDatePanel.setBackground(COLOR_LIGHT_GRAY);
        JLabel startDateLabel = new JLabel("Start Date:");
        startDateLabel.setForeground(Color.WHITE);
        startDateField = new JFormattedTextField(dateFormat);
        startDateField.setColumns(10);
        startDatePanel.add(startDateLabel);
        startDatePanel.add(startDateField);

        // End Date components
        JPanel endDatePanel = new JPanel();
        endDatePanel.setBounds(740, 670, 300, 100);
        endDatePanel.setBackground(COLOR_LIGHT_GRAY);
        JLabel endDateLabel = new JLabel("End Date:");
        endDateLabel.setForeground(Color.WHITE);
        endDateField = new JFormattedTextField(dateFormat);
        endDateField.setColumns(10);
        endDatePanel.add(endDateLabel);
        endDatePanel.add(endDateField);

        // Query Button
        JButton queryButton = new JButton("Query");
        customizeButton(queryButton);
        queryButton.setBounds(740, 700, 150, 50);
        queryButton.addActionListener(e -> calculatePeriodHoliday(startDateField.getText(), endDateField.getText()));

        datePanel.add(startDatePanel);
        datePanel.add(endDatePanel);
        datePanel.add(queryButton);
        datePanel.add(Box.createRigidArea(new Dimension(0, 10)));

        return datePanel;
    }

    public void todaysAvailableStaff(String today, String holidayStartDate, String holidayEndDate) {
        try {
            Connection conn = JDBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT StaffInfo.Staff_ID, StaffInfo.Name, StaffInfo.Role " +
                            "FROM StaffInfo " +
                            "WHERE '" + today + "' NOT BETWEEN HolidayStartDate AND HolidayEndDate"
            );

            // Reset table model
            tableModel.setRowCount(0);

            while (rs.next()) {
                String id = rs.getString("Staff_ID");
                String name = rs.getString("Name");
                String role = rs.getString("Role");

                tableModel.addRow(new Object[]{id, name, role});
            }

            JDBConnection.closeResult(rs);
            JDBConnection.closeStatement(stmt);
            JDBConnection.closeConnection(conn);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void todaysOnHolidayStaff(String today, String holidayStartDate, String holidayEndDate) {
        try {
            Connection conn = JDBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT StaffInfo.Staff_ID, StaffInfo.Name, StaffInfo.Role " +
                            "FROM StaffInfo " +
                            "WHERE '" + today + "' BETWEEN HolidayStartDate AND HolidayEndDate"
            );

            // Reset table model
            tableModel2.setRowCount(0);

            while (rs.next()) {
                String id = rs.getString("Staff_ID");
                String name = rs.getString("Name");
                String role = rs.getString("Role");

                tableModel2.addRow(new Object[]{id, name, role});
            }

            JDBConnection.closeResult(rs);
            JDBConnection.closeStatement(stmt);
            JDBConnection.closeConnection(conn);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void calculateTotalStaffWorking(String today, String holidayStartDate, String holidayEndDate) {
        try (Connection con = JDBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT SUM(CASE WHEN '" + today + "' NOT BETWEEN HolidayStartDate AND HolidayEndDate THEN 1 ELSE 0 END) AS totalStaffWorking " +
                             "FROM StaffInfo"))
        {

            while (rs.next()) {
                int totalStaffWorking = rs.getInt("TotalStaffWorking"); // Assuming TotalStaffWorking is an integer

                SwingUtilities.invokeLater(() -> {
                    String htmlText = String.format(
                            "<html>" +
                                    "<div style='font-size:14px;font-family:Helvetica; font-weight:bold; text-align: center; color: white;'>%d</div>" +
                                    "</html>", totalStaffWorking);
                    totalStaffWorkingLabel.setText(htmlText);
                });
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> {
                totalStaffWorkingLabel.setText("<html>Failed to calculate<br>total number of staff<br>working today");
            });
        }
    }

    public void calculateTotalStaffOnHoliday(String today, String holidayStartDate, String holidayEndDate) {
        try (Connection con = JDBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT SUM(CASE WHEN '" + today + "' BETWEEN HolidayStartDate AND HolidayEndDate THEN 1 ELSE 0 END) AS totalStaffOnHoliday " +
                             "FROM StaffInfo"))
        {

            while (rs.next()) {
                int totalStaffOnHoliday = rs.getInt("TotalStaffOnHoliday"); // Assuming TotalStaffWorking is an integer

                SwingUtilities.invokeLater(() -> {
                    String htmlText = String.format(
                            "<html>" +
                                    "<div style='font-size:14px;font-family:Helvetica; font-weight:bold; text-align: center; color: white;'>%d</div>" +
                                    "</html>", totalStaffOnHoliday);
                    totalStaffOnHolidayLabel.setText(htmlText);
                });
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> {
                totalStaffOnHolidayLabel.setText("<html>Failed to calculate<br>total number of staff<br>on holiday today");
            });
        }
    }

    public void calculatePeriodHoliday(String holidayStartDate, String holidayEndDate) {
        try (Connection con = JDBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT StaffInfo.Staff_ID, StaffInfo.Name, StaffInfo.Role, StaffInfo.HolidayStartDate, StaffInfo.HolidayEndDate " +
                             "FROM StaffInfo " +
                             "WHERE StaffInfo.HolidayStartDate BETWEEN '" + holidayStartDate + "' AND '" + holidayEndDate + "'")) {


            StringBuilder result = new StringBuilder("<html><body style='text-align:left;'>");
            while (rs.next()) {
                result.append(String.format(
                        "<div style='margin:5px;'>" +
                                "<span style='font-weight:bold;color:#FFD700;'>Name:</span> %s<br/>" +
                                "<span style='font-weight:bold;color:#FFD700;'>Staff ID:</span> %s<br/>" +
                                "<span style='font-weight:bold;color:#FFD700;'>Role:</span> %s" +
                                "</div>",
                        rs.getString("Name"), rs.getString("Staff_ID"), rs.getString("Role")));
            }
            result.append("</body></html>");
            periodHolidayLabel.setText(result.toString());
            periodHolidayLabel.setVerticalAlignment(SwingConstants.TOP);
        }
        catch (SQLException e) {
            e.printStackTrace();
            periodHolidayLabel.setText("<html>Failed to calculate<br>staff on holidays over<br>particular days selected</html>");
        }
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();

        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(COLOR_LIGHT_GRAY);

        try {
            BufferedImage logoImage = ImageIO.read(new File("images/logoRoot.png"));
            int diameter = 80; // Increase the diameter size of logo

            // Resize image
            Image scaledImage = logoImage.getScaledInstance(diameter, diameter, Image.SCALE_SMOOTH);
            BufferedImage resizedImage = new BufferedImage(diameter, diameter, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2dResized = resizedImage.createGraphics();
            g2dResized.drawImage(scaledImage, 0, 0, null);
            g2dResized.dispose();

            ImageIcon logoIcon = new ImageIcon(scaledImage);
            JLabel logoLabel = new JLabel(logoIcon);

            // Center the logo label horizontally in the sidebar
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebar.add(Box.createRigidArea(new Dimension(0, 15))); // offset from top of sidebar

            // Add logo label to sidebar
            sidebar.add(logoLabel);
            sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
            //sidebar.add(Box.createVerticalGlue());

            sidebar.add(createSidebarButton("Home"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20))); // Spacing between buttons
            sidebar.add(createSidebarButton("Bookings"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Review Menu"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Staff Tracking"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Sales"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Wine"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Order Ingredients"));
        }
        catch (Exception e) {
            System.out.println("Error fetching sidebar data: " + e.getMessage());
        }

        return sidebar;
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton("<html><center>" + text.replaceAll(" ", "<br>") + "</center></html>");

        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setPreferredSize(new Dimension(150, 75));
        button.setMaximumSize(new Dimension(150, button.getPreferredSize().height));
        button.setBackground(COLOR_DARK_GRAY);
        button.setForeground(COLOR_TEXT);
        button.setFocusPainted(false);
        button.setBorderPainted(false);

        // Change font and size of text in button:
        button.setFont(new Font("Helvetica", Font.BOLD, 16));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(COLOR_LIGHT_GRAY.brighter());
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(COLOR_DARK_GRAY);
            }
        });

        button.addActionListener(e -> {
            switch (text) {
                case "Home":
                    //System.out.println("Home button");
                    mainFrame.switchToMainMenu();
                    return;

                case "Bookings":
                    //System.out.println("Bookings button");
                    mainFrame.switchToBooking();
                    return;

                case "Review Menu":
                    //System.out.println("Review Menu button");
                    mainFrame.switchToReviewMenu();
                    return;

                case "Staff Tracking":
                    //System.out.println("Staff Tracking button");
                    return;

                case "Sales":
                    //System.out.println("Sales button");
                    mainFrame.switchToSales();
                    return;

                case "Wine":
                    //System.out.println("Wine button");
                    mainFrame.switchToWine();
                    return;

                case "Order Ingredients":
                    //System.out.println("Order Ingredients button");
                    mainFrame.switchToOrderIngredients();
                    return;
            }
        });

        return button;

    }

    private JLabel createCard(String title, String content, JPanel panelContainer) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(COLOR_LIGHT_GRAY);

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setForeground(COLOR_TEXT);
        card.add(titleLabel, BorderLayout.NORTH);

        JLabel contentLabel = new JLabel(content, SwingConstants.CENTER);
        contentLabel.setForeground(COLOR_TEXT);
        card.add(contentLabel, BorderLayout.CENTER);

        card.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panelContainer.add(card);
        return contentLabel;
    }

    private void deleteSelectedStaff(JTable table) {
        int selectedRow = table.getSelectedRow();
        System.out.println("");
        try {
            if (selectedRow >= 0) {
                int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete the selected staff member?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    // Get the staff ID from the selected row
                    int staffID = Integer.parseInt((String) table.getValueAt(selectedRow, 0));
                    Connection conn = JDBConnection.getConnection();

                    System.out.println("connected OK");

                    if (conn != null) {
                        System.out.println("in statement OK");
                        Statement stmt = conn.createStatement();
                        // Execute the DELETE SQL statement
                        String sql = "DELETE FROM StaffInfo WHERE Staff_ID = " + staffID;
                        System.out.println("sql = " + sql);

                        stmt.executeUpdate(sql);
                    }
                    // Refresh table
                    todaysAvailableStaff(currentDateString, holidayStartDate, holidayEndDate);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a staff member to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void addSelectedStaff(JTable table){
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to add a staff member?", "Confirm change in table", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            // Get the staff ID from the selected row
            try {
                String id = JOptionPane.showInputDialog(this, "Enter staff ID:");
                String name = JOptionPane.showInputDialog(this, "Enter staff name:");
                String role = JOptionPane.showInputDialog(this, "Enter staff role:");
                String holidayStartDate = JOptionPane.showInputDialog(this, "Enter staff holiday start date:");
                String holidayEndDate = JOptionPane.showInputDialog(this, "Enter staff holiday start date:");

                Connection conn = JDBConnection.getConnection();
                if (conn != null) {
                    Statement stmt = conn.createStatement();
                    // Execute the INSERT SQL statement
                    if (table == staffAvailableTable) {
                        String sql = "INSERT INTO StaffInfo (Staff_ID, Name, Role, HolidayStartDate, HolidayEndDate) VALUES ('" + id + "', '" + name + "', '" + role + "', '" + holidayStartDate + "', '" + holidayEndDate + "')";
                        stmt.executeUpdate(sql);
                    } else {
                        JOptionPane.showMessageDialog(this, "This data does not belong in this table.", "Error", JOptionPane.WARNING_MESSAGE);
                    }

                    if (table == staffOnHolidayTable) {
                        String sql = "INSERT INTO StaffInfo (Staff_ID, Name, Role, HolidayStartDate, HolidayEndDate) VALUES ('" + id + "', '" + name + "', '" + role + "', '" + holidayStartDate + "', '" + holidayEndDate + "')";
                        stmt.executeUpdate(sql);
                    } else {
                        JOptionPane.showMessageDialog(this, "This data does not belong in this table.", "Error", JOptionPane.WARNING_MESSAGE);
                    }
                }
                // Refresh table
                todaysAvailableStaff(currentDateString, holidayStartDate, holidayEndDate);
                todaysOnHolidayStaff(currentDateString, holidayStartDate, holidayEndDate);

                JOptionPane.showMessageDialog(this, "Correction realised: Succesfully added staff member into the correct ", "Correction", JOptionPane.PLAIN_MESSAGE);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }


    private void updateSelectedStaff(JTable table) { //CHANGE THEIR HOLIDAY DATES! Changing other fields: UPDATE in other classes
        int selectedRow = table.getSelectedRow();
        System.out.println("");
        if (selectedRow >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to update the selected staff member?", "Confirm change in staff member information", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                // Get the staff ID from the selected row
                try {
                    String holidayStartDate = JOptionPane.showInputDialog(this, "Enter staff holiday start date:");
                    String holidayEndDate = JOptionPane.showInputDialog(this, "Enter staff holiday start date:");

                    int staffID = Integer.parseInt((String) table.getValueAt(selectedRow, 0));
                    Connection conn = JDBConnection.getConnection();
                    if (conn != null) {
                        Statement stmt = conn.createStatement();
                        // Execute the INSERT SQL statement
                        String sql = "UPDATE StaffInfo SET HolidayStartDate = '" + holidayStartDate + "', HolidayEndDate = '" + holidayEndDate + "' WHERE Staff_ID = " + staffID;
                        stmt.executeUpdate(sql);
                    }
                    // Refresh table
                    todaysAvailableStaff(currentDateString, holidayStartDate, holidayEndDate);
                    todaysOnHolidayStaff(currentDateString, holidayStartDate, holidayEndDate);

                    JOptionPane.showMessageDialog(this, "Successfully updated staff member holiday information", "Success", JOptionPane.PLAIN_MESSAGE);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    public void addStaffButtonMethod(int x, int y, int w, int h, JTable table) {
        JButton addStaffButton = new JButton("Add");
        customizeButton(addStaffButton);
        addStaffButton.addActionListener(e -> addSelectedStaff(table));
        addStaffButton.setBounds(x, y, w, h);
        addStaffButton.setBackground(BUTTON_LIGHT);
        addStaffButton.setFocusPainted(false);
        addStaffButton.setBorderPainted(false);
        addStaffButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                addStaffButton.setBackground(COLOR_WHITE.brighter()); // Lighter shade on hover
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                addStaffButton.setBackground(BUTTON_LIGHT); // Original color when not hovered
            }
        });

        contentArea.add(addStaffButton);
    }


    public void updateStaffButtonMethod(int x, int y, int w, int h, JTable table) {
        JButton updateStaffButton = new JButton("Update");
        customizeButton(updateStaffButton);
        updateStaffButton.addActionListener(e -> updateSelectedStaff(table));
        updateStaffButton.setBounds(x, y, w, h);
        updateStaffButton.setBackground(BUTTON_LIGHT);
        updateStaffButton.setFocusPainted(false);
        updateStaffButton.setBorderPainted(false);
        updateStaffButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                updateStaffButton.setBackground(COLOR_WHITE.brighter()); // Lighter shade on hover
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                updateStaffButton.setBackground(BUTTON_LIGHT); // Original color when not hovered
            }
        });

        contentArea.add(updateStaffButton);
    }

    public void deleteStaffButtonMethod(int x, int y, int w, int h, JTable table) {
        JButton deleteStaffButton = new JButton("Delete");
        customizeButton(deleteStaffButton);
        deleteStaffButton.addActionListener(e -> deleteSelectedStaff(table));
        deleteStaffButton.setBounds(x, y, w, h);
        deleteStaffButton.setBackground(BUTTON_LIGHT);
        deleteStaffButton.setFocusPainted(false);
        deleteStaffButton.setBorderPainted(false);
        deleteStaffButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                deleteStaffButton.setBackground(COLOR_WHITE.brighter()); // Lighter shade on hover
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                deleteStaffButton.setBackground(BUTTON_LIGHT); // Original color when not hovered
            }
        });

        contentArea.add(deleteStaffButton);
    }

    private void customizeButton(JButton button) {
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFocusPainted(false);
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.repaint();
            }
        });
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                JButton b = (JButton) c;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (b.getModel().isRollover()) {
                    g2.setColor(new Color(115,116,124));
                } else {
                    g2.setColor(new Color(160,160,160));
                }
                g2.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), 30, 30);
                g2.dispose();
                super.paint(g, c);
            }
        });
    }

    public void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StaffTrackingGUI staffTrackingGUI = new StaffTrackingGUI(this.mainFrame);
            staffTrackingGUI.setVisible(true);
        });
    }
}