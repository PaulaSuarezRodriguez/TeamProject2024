import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.*;
import javax.swing.table.DefaultTableModel;


public class WineGUI extends JPanel {

    private ApplicationFrame mainFrame;

    private JTable orderTable;
    private DefaultTableModel tableModel;
    private JTextField wineNameField,wineYearField,quantityField;
    private JButton addButton, deleteButton;

    private static final Color COLOR_DARK_GRAY = new Color(50, 50, 50);
    private static final Color COLOR_LIGHT_GRAY = new Color(75, 75, 75);
    private static final Color COLOR_BACKGROUND = new Color(42, 52, 54);
    private static final Color COLOR_TEXT = Color.WHITE;
    private static final Font titleFont = new Font("Helvetica", Font.BOLD, 18);
    private static final Font pageTitleFont = new Font("Helvetica", Font.BOLD, 25);

    JPanel contentArea = new JPanel(null);

    public WineGUI(JFrame mainFrame) {

        this.mainFrame = (ApplicationFrame) mainFrame;
        setLayout(new BorderLayout());
        setSize(1200, 720);

        JPanel sidebar = createSidebar();
        add(sidebar, BorderLayout.WEST);

        contentArea = new JPanel(null);
        contentArea.setBackground(COLOR_BACKGROUND);

        JLabel pageNameLabel = new JLabel("Wines");
        pageNameLabel.setFont(pageTitleFont);
        pageNameLabel.setForeground(COLOR_TEXT);
        pageNameLabel.setBounds(465, 0, 200, 100);
        contentArea.add(pageNameLabel);

        JPanel area = new JPanel();
        area.setLayout(null);
        area.setBackground(COLOR_LIGHT_GRAY);
        area.setBounds(380, 380, 300, 300);
        contentArea.add(area);

        JLabel wineLabel = new JLabel("Wine Name:");
        wineLabel.setForeground(COLOR_TEXT);
        wineLabel.setBounds(50, 20, 200, 25);
        area.add(wineLabel);
        wineNameField = new JTextField();
        wineNameField.setBounds(50, 50, 200, 25);
        area.add(wineNameField);

        JLabel yearLabel = new JLabel("Wine Year:");
        yearLabel.setForeground(COLOR_TEXT);
        yearLabel.setBounds(50, 80, 200, 25);
        area.add(yearLabel);
        wineYearField = new JTextField();
        wineYearField.setBounds(50, 110, 200, 25);
        area.add(wineYearField);

        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setForeground(COLOR_TEXT);
        quantityLabel.setBounds(50, 140, 200, 25);
        area.add(quantityLabel);
        quantityField = new JTextField();
        quantityField.setBounds(50, 170, 200, 25);
        area.add(quantityField);

        addButton = new JButton("Add");
        customizeButton(addButton);
        addButton.setBounds(50, 210, 200, 25);
        addButton.setBackground(COLOR_LIGHT_GRAY);
        addButton.setForeground(COLOR_TEXT);
        area.add(addButton);
        addButton.addActionListener(e -> addWine(wineNameField.getText(), Integer.parseInt(wineYearField.getText()), Integer.parseInt(quantityField.getText())));


        deleteButton = new JButton("Delete Selected");
        customizeButton(deleteButton);
        deleteButton.setBounds(50, 240, 200, 25);
        deleteButton.setBackground(COLOR_LIGHT_GRAY);
        deleteButton.setForeground(COLOR_TEXT);
        area.add(deleteButton);
        deleteButton.addActionListener(e -> {
            int selectedRow = orderTable.getSelectedRow();
            if (selectedRow >= 0) {
                int wineID = (int) tableModel.getValueAt(selectedRow, 0); // Assuming the Wine ID is in the first column
                deleteWine(wineID);
            } else {
                JOptionPane.showMessageDialog(this, "Please select a wine to delete.");
            }
        });
        add(contentArea);
        setupOrderTable();
    }



    private void setupOrderTable() {
        // Define the column names for the table
        String[] columnNames = {"Wine ID", "Name", "Year", "Quantity"};

        tableModel = new DefaultTableModel(columnNames, 0);
        orderTable = new JTable(tableModel);

        orderTable.setFillsViewportHeight(true);

        JScrollPane scrollPane = new JScrollPane(orderTable);
        scrollPane.setBounds(170, 75, 700, 300);
        contentArea.add(scrollPane);
        fetchWinesFromDatabase();
    }

    private void fetchWinesFromDatabase() {
        try {
            Connection conn = JDBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM SommelierBook");

            // Reset table model
            tableModel.setRowCount(0);

            while (rs.next()) {
                // Assuming your table columns match these data types
                int wineID = rs.getInt("wine_ID");
                String name = rs.getString("Name");
                int year = rs.getInt("Year");
                int quantity = rs.getInt("StockQuantity");
                tableModel.addRow(new Object[]{wineID, name, year, quantity});
            }

            JDBConnection.closeResult(rs);
            JDBConnection.closeStatement(stmt);
            JDBConnection.closeConnection(conn);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void addWine(String name, int year, int stockQuantity) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            //Establish connection to the DB
            connection = JDBConnection.getConnection();

            //Prepare SQL statement
            String query = "INSERT INTO SommelierBook (Name, Year, StockQuantity) VALUES (?, ?, ?)";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, year);
            preparedStatement.setInt(3, stockQuantity);

            //Execute
            preparedStatement.executeUpdate();
            System.out.println("Wine added successfully.");

            fetchWinesFromDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBConnection.closeStatement(preparedStatement);
            JDBConnection.closeConnection(connection);
        }
    }



    public void deleteWine(int wineID){
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            //Establish connection
            connection = JDBConnection.getConnection();

            //Prepare SQL statement
            String query = "DELETE FROM SommelierBook WHERE wine_ID = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, wineID);

            //Execute
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Wine with ID " + wineID + " deleted successfully.");
            } else {
                System.out.println("No wine found with ID " + wineID + ". No rows deleted.");
            }

            fetchWinesFromDatabase();
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            JDBConnection.closeConnection(connection);
            JDBConnection.closeStatement(preparedStatement);
        }
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();

        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(COLOR_LIGHT_GRAY);

        try {
            BufferedImage logoImage = ImageIO.read(new File("images/logoRoot.png"));
            int diameter = 80; // Increase the diameter size of logo

            // Resize image
            Image scaledImage = logoImage.getScaledInstance(diameter, diameter, Image.SCALE_SMOOTH);
            BufferedImage resizedImage = new BufferedImage(diameter, diameter, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2dResized = resizedImage.createGraphics();
            g2dResized.drawImage(scaledImage, 0, 0, null);
            g2dResized.dispose();

            ImageIcon logoIcon = new ImageIcon(scaledImage);
            JLabel logoLabel = new JLabel(logoIcon);

            // Center the logo label horizontally in the sidebar
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebar.add(Box.createRigidArea(new Dimension(0, 15))); // offset from top of sidebar

            // Add logo label to sidebar
            sidebar.add(logoLabel);
            sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
            //sidebar.add(Box.createVerticalGlue());

            sidebar.add(createSidebarButton("Home"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20))); // Spacing between buttons
            sidebar.add(createSidebarButton("Bookings"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Review Menu"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Staff Tracking"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Sales"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Wine"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Order Ingredients"));
        }
        catch (Exception e) {
            System.out.println("Error fetching sidebar data: " + e.getMessage());
        }

        return sidebar;
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton("<html><center>" + text.replaceAll(" ", "<br>") + "</center></html>");

        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setPreferredSize(new Dimension(150, 75));
        button.setMaximumSize(new Dimension(150, button.getPreferredSize().height));
        button.setBackground(COLOR_DARK_GRAY);
        button.setForeground(COLOR_TEXT);
        button.setFocusPainted(false);
        button.setBorderPainted(false);

        // Change font and size of text in button:
        button.setFont(new Font("Helvetica", Font.BOLD, 16));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(COLOR_LIGHT_GRAY.brighter());
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(COLOR_DARK_GRAY);
            }
        });

        button.addActionListener(e -> {
            switch (text) {
                case "Home":
                    //System.out.println("Home button");
                    mainFrame.switchToMainMenu();
                    return;

                case "Bookings":
                    //System.out.println("Bookings button");
                    mainFrame.switchToBooking();
                    return;

                case "Review Menu":
                    //System.out.println("Review Menu button");
                    mainFrame.switchToReviewMenu();
                    return;

                case "Staff Tracking":
                    //System.out.println("Staff Tracking button");
                    mainFrame.switchToStaffTracking();
                    return;

                case "Sales":
                    //System.out.println("Sales button");
                    mainFrame.switchToSales();
                    return;

                case "Wine":
                    //System.out.println("Wine button");
                    return;

                case "Order Ingredients":
                    //System.out.println("Order Ingredients button");
                    mainFrame.switchToOrderIngredients();
                    return;
            }
        });

        return button;
    }

    private void customizeButton(JButton button) {
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFocusPainted(false);
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.repaint();
            }
        });
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                JButton b = (JButton) c;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (b.getModel().isRollover()) {
                    g2.setColor(new Color(115,116,124));
                } else {
                    g2.setColor(new Color(160,160,160));
                }
                g2.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), 30, 30);
                g2.dispose();
                super.paint(g, c);
            }
        });
    }

    public void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            WineGUI wineGUI = new WineGUI(this.mainFrame);
            wineGUI.setVisible(true);
        });
    }

}
