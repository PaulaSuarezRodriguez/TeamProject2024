import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.sql.*;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.time.LocalDate;

public class MainMenuGUI extends JPanel {

    private ApplicationFrame mainFrame;

    private static final Color COLOR_DARK_GRAY = new Color(50, 50, 50);
    private static final Color COLOR_LIGHT_GRAY = new Color(75, 75, 75);

    private static final Color BUTTON_LIGHT = new Color(180, 180, 180);

    private static final Color COLOR_BACKGROUND = new Color(42, 52, 54);
    private static final Color COLOR_WHITE = new Color(255, 255, 255);

    private static final Font titleFont = new Font("Helvetica", Font.BOLD, 18);
    private static final Font pageTitleFont = new Font("Helvetica", Font.BOLD, 25);
    private static final Font textFont = new Font("Helvetica", Font.BOLD, 16);

    private static final Color COLOR_TEXT = Color.WHITE;

    private static JLabel currentRevenueLabel;
    private static JLabel totalOrdersLabel;

    private JPanel revenueGraphPanel;
    private JLabel revenueGraphTitle;
    private Map<String, Double> weeklyRevenue = getWeeklyRevenue();

    private JPanel totalCostGraphPanel;
    private JLabel totalCostGraphLabel;
    private Map<String, Integer> totalCost = calculateIngredientCostsMap();

    private JPanel upcomingBookingsPanel;
    private JLabel upcomingBookingsLabel;
    private Map<String, Integer> upcomingBookings = getUpcomingBookingsMap();


    public MainMenuGUI(JFrame mainFrame) {

        //setTitle("Lancaster Main Menu");
        this.mainFrame = (ApplicationFrame) mainFrame;
        setLayout(new BorderLayout());
        setSize(1200, 720);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel sideBar = createSidebar();
        add(sideBar, BorderLayout.WEST);

        JPanel contentArea = new JPanel(null);
        contentArea.setBackground(COLOR_BACKGROUND);

        JLabel pageNameLabel = new JLabel("Main Menu");
        pageNameLabel.setFont(pageTitleFont);
        pageNameLabel.setForeground(COLOR_TEXT);
        pageNameLabel.setBounds(465, 0, 200, 100);
        contentArea.add(pageNameLabel);

        JPanel currentRevenueCard = new JPanel();
        currentRevenueCard.setBounds(250, 100, 250, 100);
        currentRevenueCard.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(currentRevenueCard);
        currentRevenueLabel = createCard("Current Revenue:", null, currentRevenueCard);

        JPanel totalOrdersCard = new JPanel();
        totalOrdersCard.setBounds(550, 100, 250, 100);
        totalOrdersCard.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(totalOrdersCard);
        totalOrdersLabel = createCard("Total Orders Today:", null, totalOrdersCard);

        revenueGraphPanel = new RevenueGraphPanel();
        revenueGraphPanel.setBounds(100, 250, 400, 180);
        revenueGraphPanel.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(revenueGraphPanel);
        revenueGraphTitle = createCard("Revenue graph:", null, revenueGraphPanel);

        totalCostGraphPanel = new TotalCostGraphPanel();
        totalCostGraphPanel.setBounds(550, 250, 400, 180);
        totalCostGraphPanel.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(totalCostGraphPanel);
        totalCostGraphLabel = createCard("Total Cost:", null, totalCostGraphPanel);

        upcomingBookingsPanel = new JPanel();
        upcomingBookingsPanel.setBounds(100, 475, 850, 190);
        upcomingBookingsPanel.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(upcomingBookingsPanel);
        upcomingBookingsLabel = createCard("Upcoming Bookings:", null, upcomingBookingsPanel);

        add(contentArea, BorderLayout.CENTER);
        calculateCurrentRevenue();
        calculateTotalOrdersToday();
        calculateWeeklyRevenue();

        displayUpcomingBookings(upcomingBookings);
    }

    private void calculateCurrentRevenue() {

        String query = "SELECT SUM(d.Price * s.QuantitySold) AS TotalRevenue " +
                "FROM DailySales s " +
                "JOIN Dishes d ON s.Dish_ID = d.Dish_ID " +
                "WHERE s.SaleDate = CURDATE();";

        try (Connection conn = JDBConnection.getConnection(); // Make sure this method exists and is imported
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                double totalRevenue = rs.getDouble("TotalRevenue");
                SwingUtilities.invokeLater(() -> currentRevenueLabel.setText("£" + String.format("%.2f", totalRevenue)));
            } else {
                SwingUtilities.invokeLater(() -> currentRevenueLabel.setText("No sales for today."));
            }
        } catch (Exception e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> currentRevenueLabel.setText("Error calculating revenue."));
        }
    }

    private void calculateTotalOrdersToday() {

        String query = "SELECT COUNT(*) AS OrderCount FROM Orders WHERE OrderDate = CURDATE();";

        try (Connection conn = JDBConnection.getConnection(); // Make sure this method exists and is imported
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next()) {
                int orderCount = rs.getInt("OrderCount");
                SwingUtilities.invokeLater(() -> totalOrdersLabel.setText(String.valueOf(orderCount)));
            } else {
                SwingUtilities.invokeLater(() -> totalOrdersLabel.setText("No orders for today."));
            }
        } catch (Exception e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> totalOrdersLabel.setText("Error fetching order data."));
        }
    }

    private void calculateWeeklyRevenue() {
        String query = "SELECT YEARWEEK(s.SaleDate) as SaleWeek, SUM(d.Price * s.QuantitySold) AS WeeklyRevenue " +
                "FROM DailySales s " +
                "JOIN Dishes d ON s.Dish_ID = d.Dish_ID " +
                "WHERE s.SaleDate BETWEEN CURDATE() - INTERVAL 4 WEEK AND CURDATE() " +
                "GROUP BY YEARWEEK(s.SaleDate) " +
                "ORDER BY SaleWeek ASC;";

        Map<String, Double> weeklyRevenueMap = new LinkedHashMap<>();
        try (Connection conn = JDBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String saleWeek = rs.getString("SaleWeek");
                double weeklyRevenue = rs.getDouble("WeeklyRevenue");
                weeklyRevenueMap.put(saleWeek, weeklyRevenue);
            }
        }
        catch (Exception e) {
            System.out.println("Error getting weekly revenue: " + e.getMessage());
        }

        SwingUtilities.invokeLater(() -> {
            revenueGraphPanel.repaint();
        });
    }

    private Map<String, Double> getWeeklyRevenue() {
        Map<String, Double> revenueMap = new LinkedHashMap<>();
        String query = "SELECT DATE(SaleDate) AS SaleDay, SUM(d.Price * s.QuantitySold) AS DailyRevenue " +
                "FROM DailySales s " +
                "JOIN Dishes d ON s.Dish_ID = d.Dish_ID " +
                "WHERE s.SaleDate BETWEEN ? AND ? " +
                "GROUP BY DATE(SaleDate) " +
                "ORDER BY SaleDay ASC;";

        LocalDate today = LocalDate.now();
        LocalDate sevenDaysAgo = today.minusDays(6); // include today, so it's six days ago

        try (Connection conn = JDBConnection.getConnection();

             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setDate(1, Date.valueOf(sevenDaysAgo));
            pstmt.setDate(2, Date.valueOf(today));

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    String saleDay = rs.getString("SaleDay");
                    double dailyRevenue = rs.getDouble("DailyRevenue");
                    revenueMap.put(saleDay, dailyRevenue);
                }
            }
        }

        catch (Exception e) {
            System.out.println("Error saving weekly revenue: " + e.getMessage());
        }

        //System.out.println(revenueMap);
        return revenueMap;
    }

    private class RevenueGraphPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (weeklyRevenue != null) {
                drawBarChart(g, weeklyRevenue);
            }
        }
    }

    private void drawBarChart(Graphics g, Map<String, Double> data) {
        int panelWidth = revenueGraphPanel.getWidth();
        int panelHeight = revenueGraphPanel.getHeight(); // leave some space for the title

        double maxRevenue = data.values().stream().max(Double::compare).orElse(0.0);
        int numberOfBars = data.size();
        int barWidth = (panelWidth - (numberOfBars + 1) * 5) / numberOfBars; // bar width with padding

        int x = 5; // start position with initial padding
        for (Map.Entry<String, Double> entry : data.entrySet()) {

            double value = entry.getValue();
            int barHeight = (int) ((value / maxRevenue) * (panelHeight - 60)); // scale bar height
            int y = panelHeight - barHeight - 20;

            // Draw the bar
            g.setColor(Color.WHITE);
            g.fillRect(x, y, barWidth, barHeight);

            // Draw the value inside the bar if it fits, otherwise above the bar
            String valueStr = String.format("%.2f", value);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Helvetica", Font.BOLD, 10)); // smaller font for the values
            int stringWidth = g.getFontMetrics().stringWidth(valueStr);
            int stringHeight = g.getFontMetrics().getHeight();

            int stringX = x + (barWidth - stringWidth) / 2; // center the text in the bar
            int stringY = y + ((barHeight > stringHeight + 5) ? (stringHeight + 5) : -5); // 5px padding from top

            g.setColor(Color.BLACK);
            g.drawString("£" + valueStr, stringX, stringY);

            // Draw the date label beneath the bar
            g.setColor(Color.WHITE);
            String dateStr = formatDateLabel(entry.getKey()); // Assuming entry.getKey() is the date string
            stringWidth = g.getFontMetrics().stringWidth(dateStr);
            g.drawString(dateStr, x + (barWidth - stringWidth) / 2, panelHeight - 5);
            // Move to the next bar's x position
            x += barWidth + 5; // 5px padding between bars
        }
    }

    private String formatDateLabel(String dateStr) {
        LocalDate date = LocalDate.parse(dateStr);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("E dd"); // Format like "Mon 08/04"
        return date.format(formatter);
    }

    private Map<String, Integer> getUpcomingBookingsMap() {
        Map<String, Integer> bookingsMap = new LinkedHashMap<>();
        String query = "SELECT BookingDate, SUM(NumberOfGuests) AS TotalGuests " +
                "FROM Booking " +
                "WHERE BookingDate BETWEEN CURDATE() AND CURDATE() + INTERVAL 3 DAY " +
                "GROUP BY BookingDate " +
                "ORDER BY BookingDate ASC;";

        try (Connection conn = JDBConnection.getConnection(); // Make sure this method is correctly implemented
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                // Format the date as a string
                String dateStr = rs.getDate("BookingDate").toString();
                int totalGuests = rs.getInt("TotalGuests");
                bookingsMap.put(dateStr, totalGuests);
            }
        } catch (SQLException e) {
            System.out.println("Error getting upcoming booking data: " + e.getMessage());
        }
        //System.out.println(bookingsMap);
        return bookingsMap;
    }

    private void displayUpcomingBookings(Map<String, Integer> bookingsMap) {
        // Clear the panel before adding new components
        //upcomingBookingsPanel.removeAll();

        // Set a BoxLayout with vertical alignment
        upcomingBookingsPanel.setLayout(new BoxLayout(upcomingBookingsPanel, BoxLayout.Y_AXIS));

        // Define a DateTimeFormatter for the day of the week and the date
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("EEEE dd", Locale.ENGLISH);

        // Loop through each booking entry in the map
        for (Map.Entry<String, Integer> entry : bookingsMap.entrySet()) {
            String dateStr = entry.getKey();
            Integer guests = entry.getValue();

            // Parse the date string to a LocalDate
            LocalDate date = LocalDate.parse(dateStr);

            // Format the date to include the day of the week and the date
            String formattedDate = date.format(dateFormatter);

            // Create a label for each booking entry with formatted date
            JLabel bookingLabel = new JLabel("Date: " + formattedDate + "                 Total Guests: " + guests);
            bookingLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Align to the center of the panel
            bookingLabel.setForeground(COLOR_TEXT); // Set the text color
            bookingLabel.setFont(new Font("Helvetica", Font.BOLD, 16)); // Set the font

            // Add a margin between the label and the edges of the panel
            bookingLabel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));

            // Add the label to the panel
            upcomingBookingsPanel.add(bookingLabel);
        }

        // Refresh the panel to display the new labels
        upcomingBookingsPanel.revalidate();
        upcomingBookingsPanel.repaint();
    }

    private Map<String, Integer> calculateIngredientCostsMap() {
        Map<String, Integer> totalCostMap = new LinkedHashMap<>();
        String query = "SELECT DATE(o.OrderDate) AS OrderDay, SUM(i.Price * io.Quantity) AS TotalCost\n" +
                "FROM Orders o\n" +
                "JOIN IngredientOrders io ON o.Order_ID = io.Order_ID\n" +
                "JOIN Ingredient i ON io.Ingredient_ID = i.Ingredient_ID\n" +
                "WHERE o.OrderDate BETWEEN CURDATE() - INTERVAL 7 DAY AND CURDATE()\n" +
                "GROUP BY DATE(o.OrderDate)\n" +
                "ORDER BY OrderDay ASC;\n";

        try (Connection conn = JDBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    String orderDay = rs.getString("OrderDay");
                    int totalCost = rs.getInt("TotalCost");
                    totalCostMap.put(orderDay, totalCost);
                }
            }
        } catch (Exception e) {
            System.out.println("Error calculating ingredient costs: " + e.getMessage());
        }
        //System.out.println(totalCostMap);
        return totalCostMap;
    }

    private class TotalCostGraphPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (totalCost != null) {
                drawCostChart(g, totalCost);
            }
        }
    }

    private void drawCostChart(Graphics g, Map<String, Integer> data) {
        int panelWidth = totalCostGraphPanel.getWidth();
        int panelHeight = totalCostGraphPanel.getHeight();
        int maxCost = (Collections.max(data.values()) > 0) ? Collections.max(data.values()) : 1;

        int numberOfBars = data.size();
        int barWidth = (panelWidth - (numberOfBars + 1) * 5) / numberOfBars; // bar width with padding

        int x = 5; // Start position with initial padding
        for (Map.Entry<String, Integer> entry : data.entrySet()) {
            int value = entry.getValue();
            int barHeight = (int) ((double) value / maxCost * (panelHeight - 60)); // Scale bar height
            int y = panelHeight - barHeight - 20; // Subtract 20 for the bottom padding

            g.setColor(Color.WHITE);
            g.fillRect(x, y, barWidth, barHeight);

            g.setFont(new Font("Helvetica", Font.BOLD, 10)); // Font for the values
            String valueStr = String.format("%d", value);
            int stringWidth = g.getFontMetrics().stringWidth(valueStr);
            int stringY = y + ((barHeight > 20) ? 20 : barHeight - 5); // Adjust to draw inside the bar

            g.setColor(Color.BLACK);
            g.drawString("£" + valueStr, x + (barWidth - stringWidth) / 2, stringY);

            // Draw the date label beneath the bar
            g.setColor(Color.WHITE);
            String dateStr = formatDateLabel(entry.getKey());
            stringWidth = g.getFontMetrics().stringWidth(dateStr);
            g.drawString(dateStr, x + (barWidth - stringWidth) / 2, panelHeight - 5);

            x += barWidth + 5; // Move to the next bar's x position
        }
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();

        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(COLOR_LIGHT_GRAY);

        try {
            BufferedImage logoImage = ImageIO.read(new File("images/logoRoot.png"));
            int diameter = 80; // Increase the diameter size of logo

            // Resize image
            Image scaledImage = logoImage.getScaledInstance(diameter, diameter, Image.SCALE_SMOOTH);
            BufferedImage resizedImage = new BufferedImage(diameter, diameter, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2dResized = resizedImage.createGraphics();
            g2dResized.drawImage(scaledImage, 0, 0, null);
            g2dResized.dispose();

            ImageIcon logoIcon = new ImageIcon(scaledImage);
            JLabel logoLabel = new JLabel(logoIcon);

            // Center the logo label horizontally in the sidebar
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebar.add(Box.createRigidArea(new Dimension(0, 15))); // offset from top of sidebar

            // Add logo label to sidebar
            sidebar.add(logoLabel);
            sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
            //sidebar.add(Box.createVerticalGlue());

            sidebar.add(createSidebarButton("Home"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20))); // Spacing between buttons
            sidebar.add(createSidebarButton("Bookings"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Review Menu"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Staff Tracking"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Sales"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Wine"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Order Ingredients"));

        }
        catch (Exception e) {
            System.out.println("Error fetching sidebar data: " + e.getMessage());
        }

        return sidebar;
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton("<html><center>" + text.replaceAll(" ", "<br>") + "</center></html>");

        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setPreferredSize(new Dimension(150, 75));
        button.setMaximumSize(new Dimension(150, button.getPreferredSize().height));
        button.setBackground(COLOR_DARK_GRAY);
        button.setForeground(COLOR_TEXT);
        button.setFocusPainted(false);
        button.setBorderPainted(false);

        // Change font and size of text in button:
        button.setFont(new Font("Helvetica", Font.BOLD, 16));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(COLOR_LIGHT_GRAY.brighter());
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(COLOR_DARK_GRAY);
            }
        });

        button.addActionListener(e -> {
            switch (text) {
                case "Home":
                    //System.out.println("Home button");
                    return;

                case "Bookings":
                    //System.out.println("Bookings button");
                    mainFrame.switchToBooking();
                    return;

                case "Review Menu":
                    //System.out.println("Review Menu button");
                    mainFrame.switchToReviewMenu();
                    return;

                case "Staff Tracking":
                    //System.out.println("Staff Tracking button");
                    mainFrame.switchToStaffTracking();
                    return;

                case "Sales":
                    //System.out.println("Sales button");
                    mainFrame.switchToSales();
                    return;

                case "Wine":
                    //System.out.println("Wine button");
                    mainFrame.switchToWine();
                    return;

                case "Order Ingredients":
                    //System.out.println("Order Ingredients button");
                    mainFrame.switchToOrderIngredients();
                    return;
            }
        });

        return button;
    }

    private JLabel createCard(String title, String content, JPanel panelContainer) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(COLOR_LIGHT_GRAY);

        // Create and style the title label
        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setForeground(COLOR_TEXT);
        titleLabel.setFont(titleFont); // Set font size larger
        card.add(titleLabel, BorderLayout.NORTH);

        JLabel contentLabel = new JLabel(content, SwingConstants.CENTER);
        contentLabel.setForeground(COLOR_TEXT);
        contentLabel.setFont(new Font(contentLabel.getFont().getName(), Font.PLAIN, 36)); // Set font size larger
        card.add(contentLabel, BorderLayout.CENTER);

        card.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;

        card.add(titleLabel, gbc);
        gbc.gridy++;
        card.add(contentLabel, gbc);

        panelContainer.add(card);
        return contentLabel;
    }

    public void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
           MainMenuGUI mainMenuGUI = new MainMenuGUI(this.mainFrame);
           mainMenuGUI.setVisible(true);
        });
    }
}
