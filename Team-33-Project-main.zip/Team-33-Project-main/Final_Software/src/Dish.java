
import java.util.Set;

class Dish {
    private int dish_ID;
    private String name;
    private String description;
    private double price;
    private Set<Allergen> allergens;;


    public Dish(int dish_ID, String name, String description, double price) {
        this.dish_ID = dish_ID;
        this.name = name;
        this.description = description;
        this.price = price;


    }

    public Set<Allergen> getAllergens() {
        return allergens;
    }

    public void setAllergens(Set<Allergen> allergens) {
        this.allergens = allergens;
    }
    // Getters
    public int getDish_ID() { return dish_ID; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
}
