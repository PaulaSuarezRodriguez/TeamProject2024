import java.awt.*;

// Getters
public enum Allergen {
    CELERY("C"),    // Yellow
    CEREALS("CE"),   // Brown
    CRUSTACEANS("CR"),  // Light Blue
    EGGS("E"),
    FISH("F"),
    NUTS("N"),     // Orange
    VEGAN("VG"),       // Dark green
    VEGETARIAN("V"), // Light green
    HALAL("H");

    private final String code;


    Allergen(String code) {
        this.code = code;

    }

    public String getCode() {
        return code;
    }


}
