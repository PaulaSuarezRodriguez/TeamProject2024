import java.sql.*;

public class JDBConnection {

    private static final String URL = "jdbc:mysql://smcse-stuproj00.city.ac.uk:3306/in2033t33";
    private static final String USERNAME = "in2033t33_a";
    private static final String PASSWORD = "15WzpldHAsU";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    public static void closeConnection(Connection connection) { //closing the connection to the database.
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void closeStatement(Statement statement){ //closing the statement object
        if(statement != null){
            try{
                statement.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }

    public static void closeResult(ResultSet resultSet){ //closing the resultset object
        if(resultSet != null){
            try{
                resultSet.close();
            }
            catch(SQLException e){
                e.printStackTrace();
            }
        }
    }
}
