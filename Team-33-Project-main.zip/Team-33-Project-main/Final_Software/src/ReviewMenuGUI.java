import javax.imageio.ImageIO;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.OrientationRequested;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.awt.print.PrinterException;
import java.io.File;
import java.sql.*;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;


public class ReviewMenuGUI extends JPanel {

    private static final Color COLOR_DARK_GRAY = new Color(50, 50, 50);
    private static final Color COLOR_LIGHT_GRAY = new Color(75, 75, 75);

    private JTable tableMenu;

    private DefaultTableModel tableModel;

    private ApplicationFrame mainFrame;

    private static final Color COLOR_TEXT = Color.WHITE;


    public ReviewMenuGUI(JFrame mainFrame) {

        //setTitle("Lancaster Menu Table");
        this.mainFrame = (ApplicationFrame) mainFrame;
        setLayout(new BorderLayout());
        setSize(1200, 720);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Add the reusable sidebar
        JPanel sidebar = createSidebar();
        add(sidebar, BorderLayout.WEST);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(42, 52, 54, 255));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));
        mainPanel.add(createTitlePanel(), BorderLayout.NORTH);
        mainPanel.add(createTablePanel(), BorderLayout.CENTER);  // This now includes the table and the legend
        mainPanel.add(createButtonPanel(), BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);

        // Set the frame visible
        setVisible(true);
    }

    private JPanel createTitlePanel() {
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(42,52,54,255));
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        JLabel titleLabel = new JLabel("Review Menu");
        titleLabel.setFont(new Font("Helvetica", Font.BOLD, 30));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Ensure it's centered in the BoxLayout
        titlePanel.add(titleLabel);
        titlePanel.add(Box.createRigidArea(new Dimension(0, 10))); // Add a 10-pixel vertical space
        return titlePanel;
    }

    private JPanel createTablePanel() {
        // Table model with column names
        tableModel = new DefaultTableModel(new String[]{"Dish ID", "Name", "Description", "Price", "Allergens", "Wine Recommendation", "Course"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;  // Make cells not editable
            }
        };

        tableMenu = new JTable(tableModel);
        tableMenu.setFont(new Font("Helvetica", Font.PLAIN, 18));
        tableMenu.setRowHeight(30);
        fetchDishesFromDB();  // Populate table from DB

        TableColumnModel columnModel = tableMenu.getColumnModel();
        columnModel.getColumn(0).setMaxWidth(50);   // Dish ID
        columnModel.getColumn(1).setPreferredWidth(200);  // Name
        columnModel.getColumn(2).setPreferredWidth(800);  // Description
        columnModel.getColumn(3).setPreferredWidth(100);   // Price
        columnModel.getColumn(4).setPreferredWidth(70);  // Allergens
        columnModel.getColumn(5).setPreferredWidth(200);  // Wine Recommendation
        columnModel.getColumn(6).setPreferredWidth(100);  // Course

        JScrollPane scrollPane = new JScrollPane(tableMenu);

        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        tablePanel.add(createAllergenLegend(), BorderLayout.SOUTH);  // Add the legend panel here

        return tablePanel;
    }


    private JPanel createButtonPanel() {

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(new Color(42,52,54,255));

        JButton addButton = new JButton("ADD");
        customizeButtonLogin(addButton);
        addButton.addActionListener(e -> addRow());

        JButton deleteButton = new JButton("DELETE");
        customizeButtonLogin(deleteButton);
        deleteButton.addActionListener(e -> deleteRow());

        JButton editButton = new JButton("EDIT");
        customizeButtonLogin(editButton);
        editButton.addActionListener(e -> editRow());

        JButton saveButton = new JButton("SAVE");
        customizeButtonLogin(saveButton);
        saveButton.addActionListener(e ->saveTableAsPDF());

//                saveButton.addActionListener(e -> fetchDishesFromDB());



        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(saveButton);

        return buttonPanel;
    }

    public void fetchDishesFromDB() {
        Map<String, String> wineNames = fetchWineNames();  // Fetch wine names once and use for mapping
        try {
            Connection conn = JDBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Dishes");

            tableModel.setRowCount(0);  // Clear existing data
            while (rs.next()) {
                int dishID = rs.getInt("Dish_ID");
                String name = rs.getString("Name");
                String description = rs.getString("Description");
                float price = rs.getFloat("Price");
                String allergens = rs.getString("Allergens");
                String wineID = rs.getString("Wine_Recommendation");
                String course = rs.getString("Course");

                String wineName = wineNames.getOrDefault(wineID, "No Wine Selected");  // Replace wine ID with name using the map

                tableModel.addRow(new Object[]{dishID, name, description, price, allergens, wineName, course});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error when fetching dishes: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void addRow() {
        // Get the next Dish ID automatically
        int nextId = getNextDishId();

        String name = JOptionPane.showInputDialog(this, "Enter Name:");
        String description = JOptionPane.showInputDialog(this, "Enter Description:");
        String price = JOptionPane.showInputDialog(this, "Enter Price:");
        // Now select allergens
        String allergens = selectAllergens();  // New method to handle allergen selection

        // Existing wine recommendation selection
        Map.Entry<String, String> selectedWineEntry = selectWine();
        String wineRecommendation = selectedWineEntry != null ? selectedWineEntry.getValue() : null;
        String wineID = selectedWineEntry != null ? selectedWineEntry.getKey() : null;

        // Existing course selection
        String[] courses = {"First", "Second", "Third", "Desserts"};
        JComboBox<String> courseComboBox = new JComboBox<>(courses);
        int result = JOptionPane.showConfirmDialog(null, courseComboBox, "Select Course", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
        String course = null;
        if (result == JOptionPane.OK_OPTION) {
            course = (String) courseComboBox.getSelectedItem();
        }

        // Validation and data conversion
        if (name != null && price != null && wineRecommendation != null && course != null) {
            try {
                double priceVal = Double.parseDouble(price);
                tableModel.addRow(new Object[]{nextId, name, description, priceVal, allergens, wineRecommendation, course});
                addDish(nextId, name, description, priceVal, allergens, wineID, course);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid input for price. Please enter a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private int getNextDishId() {
        int maxId = 0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            int id = (Integer) tableModel.getValueAt(i, 0);
            if (id > maxId) {
                maxId = id;
            }
        }
        return maxId + 1; // Return the next ID
    }



    public void addDish(int dishID, String name, String description, double price, String allergens, String wineID, String course) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = JDBConnection.getConnection();
            String query = "INSERT INTO Dishes (Dish_ID, Name, Description, Price, Allergens, Wine_Recommendation, Course) VALUES (?, ?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, dishID);
            stmt.setString(2, name);
            stmt.setString(3, description);
            stmt.setDouble(4, price);
            stmt.setString(5, allergens);
            stmt.setString(6, wineID);  // Store the wine ID
            stmt.setString(7, course);

            stmt.executeUpdate();
            System.out.println("Dish added successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBConnection.closeStatement(stmt);
            JDBConnection.closeConnection(conn);
        }
    }

    private void deleteRow() {
        int selectedRow = tableMenu.getSelectedRow();
        if (selectedRow >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, "Deleting this dish will also remove all associated sales records. Are you sure you want to proceed?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                int dishID = (int) tableModel.getValueAt(selectedRow, 0);
                if (deleteDishWithSales(dishID)) {
                    tableModel.removeRow(selectedRow);
                    reassignDishIDs();
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean deleteDishWithSales(int dishID) {
        Connection conn = null;
        PreparedStatement deleteSalesStmt = null;
        PreparedStatement deleteDishStmt = null;
        boolean success = false;

        try {
            conn = JDBConnection.getConnection();
            // Disable auto-commit mode
            conn.setAutoCommit(false);

            // First, delete any sales records associated with the dish
            String deleteSalesQuery = "DELETE FROM DailySales WHERE Dish_ID = ?";
            deleteSalesStmt = conn.prepareStatement(deleteSalesQuery);
            deleteSalesStmt.setInt(1, dishID);
            deleteSalesStmt.executeUpdate();

            // Next, delete the dish
            String deleteDishQuery = "DELETE FROM Dishes WHERE Dish_ID = ?";
            deleteDishStmt = conn.prepareStatement(deleteDishQuery);
            deleteDishStmt.setInt(1, dishID);
            int rowsAffected = deleteDishStmt.executeUpdate();

            // Commit the transaction
            conn.commit();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Dish and associated sales records deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                success = true;
            }
            else {
                JOptionPane.showMessageDialog(this, "No dish found with the specified ID.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        }
        catch (Exception e) {
            // Attempt to roll back the transaction
            if (conn != null) {
                try {
                    conn.rollback();
                }
                catch (Exception ex) {
                    // Handle the rollback error
                    e.printStackTrace();
                }
            }
            JOptionPane.showMessageDialog(this, "Error deleting dish: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

        return success;
    }

    private void reassignDishIDs() {
        // Loop through the table rows and update dish IDs sequentially
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            tableModel.setValueAt(i + 1, i, 0); // Set the dish ID in the first column
            updateDishIDInDatabase(i + 1, (int) tableModel.getValueAt(i, 0)); // Update the dish ID in the database
        }
    }

    private void updateDishIDInDatabase(int newDishID, int oldDishID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = JDBConnection.getConnection();
            String query = "UPDATE Dishes SET Dish_ID = ? WHERE Dish_ID = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, newDishID);
            stmt.setInt(2, oldDishID);
            stmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error updating dish ID in the database: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            JDBConnection.closeStatement(stmt);
            JDBConnection.closeConnection(conn);
        }
    }

    public boolean deleteDish(int dishID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        boolean success = false;

        try {
            conn = JDBConnection.getConnection();
            String query = "DELETE FROM Dishes WHERE Dish_ID = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, dishID);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Dish deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                success = true;
            } else {
                JOptionPane.showMessageDialog(this, "No dish found with the specified ID.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error deleting dish: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } finally {
            JDBConnection.closeStatement(stmt);
            JDBConnection.closeConnection(conn);
        }
        return success;
    }

    private void editRow() {
        int selectedRow = tableMenu.getSelectedRow();
        int selectedColumn = tableMenu.getSelectedColumn();
        if (selectedRow == -1 || selectedColumn == -1) {
            JOptionPane.showMessageDialog(this, "Please select a cell to edit.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Object currentValue = tableModel.getValueAt(selectedRow, selectedColumn);

        // Handle different types of inputs based on the column
        switch (selectedColumn) {
            case 4: // Allergens column
                String allergens = selectAllergens();
                if (allergens != null) {
                    tableModel.setValueAt(allergens, selectedRow, selectedColumn);
                }
                break;
            case 5: // Wine Recommendation column
                Map.Entry<String, String> selectedWineEntry = selectWine();
                if (selectedWineEntry != null) {
                    tableModel.setValueAt(selectedWineEntry.getValue(), selectedRow, selectedColumn);
                }
                break;
            case 6: // Course column
                String[] courses = {"First", "Second", "Third", "Desserts"};
                JComboBox<String> courseComboBox = new JComboBox<>(courses);
                courseComboBox.setSelectedItem(currentValue);
                int result = JOptionPane.showConfirmDialog(null, courseComboBox, "Select Course", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (result == JOptionPane.OK_OPTION) {
                    String course = (String) courseComboBox.getSelectedItem();
                    tableModel.setValueAt(course, selectedRow, selectedColumn);
                }
                break;
            default:
                // For other columns, use a simple text input dialog
                String input = JOptionPane.showInputDialog(this, "Edit the value:", currentValue);
                if (input != null && !input.equals(currentValue)) {
                    tableModel.setValueAt(input, selectedRow, selectedColumn);
                }
                break;
        }

        // Update database after modification
        updateDatabase(selectedRow);
    }



    private String selectAllergens() {
        Map<String, String> allergens = new LinkedHashMap<>();
        allergens.put("C", "CELERY");
        allergens.put("CE", "CEREALS");
        allergens.put("CR", "CRUSTACEANS");
        allergens.put("E", "EGGS");
        allergens.put("F", "FISH");
        allergens.put("N", "NUTS");
        allergens.put("VG", "VEGAN");
        allergens.put("V", "VEGETARIAN");
        allergens.put("H", "HALAL");

        JCheckBox[] checkBoxes = new JCheckBox[allergens.size()];
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        int index = 0;
        for (Map.Entry<String, String> entry : allergens.entrySet()) {
            checkBoxes[index] = new JCheckBox(entry.getValue());
            panel.add(checkBoxes[index]);
            index++;
        }

        int result = JOptionPane.showConfirmDialog(null, panel, "Select Allergens", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            StringBuilder sb = new StringBuilder();
            for (JCheckBox checkBox : checkBoxes) {
                if (checkBox.isSelected()) {
                    sb.append(allergens.entrySet().stream().filter(e -> e.getValue().equals(checkBox.getText())).findFirst().get().getKey()).append(",");
                }
            }
            if (sb.length() > 0) sb.setLength(sb.length() - 1);  // Remove the trailing comma
            return sb.toString();
        }
        return null;
    }

    private JPanel createAllergenLegend() {
        JPanel legendPanel = new JPanel(new GridLayout(0, 4));  // Adjust grid layout as needed
        legendPanel.setBorder(BorderFactory.createTitledBorder("Allergen Key"));

        Map<String, String> allergens = new LinkedHashMap<>();
        allergens.put("C", "CELERY");
        allergens.put("CE", "CEREALS");
        allergens.put("CR", "CRUSTACEANS");
        allergens.put("E", "EGGS");
        allergens.put("F", "FISH");
        allergens.put("N", "NUTS");
        allergens.put("VG", "VEGAN");
        allergens.put("V", "VEGETARIAN");
        allergens.put("H", "HALAL");

        for (Map.Entry<String, String> entry : allergens.entrySet()) {
            JLabel label = new JLabel("(" + entry.getKey() + ") - " + entry.getValue());
            legendPanel.add(label);
        }

        return legendPanel;
    }

    private Map.Entry<String, String> selectWine() {
        Map<String, String> wines = new HashMap<>();
        try (Connection conn = JDBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT Wine_ID, Name, Year FROM SommelierBook");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String wineDetails = rs.getString("Name") + " (" + rs.getInt("Year") + ")";
                wines.put(String.valueOf(rs.getInt("Wine_ID")), wineDetails);
            }
            String[] wineArray = wines.values().toArray(new String[0]);
            String selectedWine = (String) JOptionPane.showInputDialog(null, "Select a wine that pairs well:",
                    "Select Wine", JOptionPane.QUESTION_MESSAGE, null, wineArray, wineArray[0]);
            for (Map.Entry<String, String> entry : wines.entrySet()) {
                if (entry.getValue().equals(selectedWine)) {
                    return entry; // Returns the ID and the wine details
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return null;
    }

    private Map<String, String> fetchWineNames() {
        Map<String, String> wineNames = new HashMap<>();
        try (Connection conn = JDBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT Wine_ID, Name, Year FROM SommelierBook");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                String wineDetails = rs.getString("Name") + " (" + rs.getString("Year") + ")";
                wineNames.put(rs.getString("Wine_ID"), wineDetails);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error when fetching wine names: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return wineNames;
    }


    private void updateDatabase(int row) {
        int dishID = Integer.parseInt(tableModel.getValueAt(row, 0).toString());
        String name = tableModel.getValueAt(row, 1).toString();
        String description = tableModel.getValueAt(row, 2).toString();
        double price = Double.parseDouble(tableModel.getValueAt(row, 3).toString());
        String allergens = tableModel.getValueAt(row, 4).toString();
        String wineRecommendation = tableModel.getValueAt(row, 5).toString();
        String course = tableModel.getValueAt(row, 6).toString();

        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = JDBConnection.getConnection();
            String query = "UPDATE Dishes SET Name = ?, Description = ?, Price = ?, Allergens = ?, Wine_Recommendation = ?, Course = ? WHERE Dish_ID = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, name);
            stmt.setString(2, description);
            stmt.setDouble(3, price);
            stmt.setInt(4, dishID);
            stmt.setString(5, allergens);
            stmt.setString(6, wineRecommendation);
            stmt.setString(7, course);


            stmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error updating dish: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            JDBConnection.closeStatement(stmt);
            JDBConnection.closeConnection(conn);
        }
    }

    public void saveTableAsPDF() {
        MessageFormat header = new MessageFormat("Menu Table");
        MessageFormat footer = new MessageFormat("Dishes Table");
        try {
            PrintRequestAttributeSet set = new HashPrintRequestAttributeSet();
            set.add(OrientationRequested.PORTRAIT);
            tableMenu.print(JTable.PrintMode.FIT_WIDTH, header, footer, true, set, true);
            JOptionPane.showMessageDialog(null, "Dishes Table created.", "Success", JOptionPane.INFORMATION_MESSAGE);

        }catch (PrinterException e){
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void customizeButtonLogin(JButton button) {
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFocusPainted(false);
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.repaint();
            }
        });
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                JButton b = (JButton) c;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (b.getModel().isRollover()) {
                    g2.setColor(new Color(115,116,124));
                } else {
                    g2.setColor(new Color(160,160,160));
                }
                g2.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), 30, 30);
                g2.dispose();
                super.paint(g, c);
            }
        });
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();

        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(COLOR_LIGHT_GRAY);

        try {
            BufferedImage logoImage = ImageIO.read(new File("images/logoRoot.png"));
            int diameter = 80; // Increase the diameter size of logo

            // Resize image
            Image scaledImage = logoImage.getScaledInstance(diameter, diameter, Image.SCALE_SMOOTH);
            BufferedImage resizedImage = new BufferedImage(diameter, diameter, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2dResized = resizedImage.createGraphics();
            g2dResized.drawImage(scaledImage, 0, 0, null);
            g2dResized.dispose();

            ImageIcon logoIcon = new ImageIcon(scaledImage);
            JLabel logoLabel = new JLabel(logoIcon);

            // Center the logo label horizontally in the sidebar
            logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
            sidebar.add(Box.createRigidArea(new Dimension(0, 15))); // offset from top of sidebar

            // Add logo label to sidebar
            sidebar.add(logoLabel);
            sidebar.add(Box.createRigidArea(new Dimension(0, 10)));
            //sidebar.add(Box.createVerticalGlue());

            sidebar.add(createSidebarButton("Home"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20))); // Spacing between buttons
            sidebar.add(createSidebarButton("Bookings"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Review Menu"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Staff Tracking"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Sales"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Wine"));
            sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
            sidebar.add(createSidebarButton("Order Ingredients"));

        }
        catch (Exception e) {
            System.out.println("Error fetching sidebar data: " + e.getMessage());
        }

        return sidebar;
    }

    private JButton createSidebarButton(String text) {
        JButton button = new JButton("<html><center>" + text.replaceAll(" ", "<br>") + "</center></html>");

        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setPreferredSize(new Dimension(150, 75));
        button.setMaximumSize(new Dimension(150, button.getPreferredSize().height));
        button.setBackground(COLOR_DARK_GRAY);
        button.setForeground(COLOR_TEXT);
        button.setFocusPainted(false);
        button.setBorderPainted(false);

        // Change font and size of text in button:
        button.setFont(new Font("Helvetica", Font.BOLD, 16));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(COLOR_LIGHT_GRAY.brighter());
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(COLOR_DARK_GRAY);
            }
        });

        button.addActionListener(e -> {
            switch (text) {
                case "Home":
                    //System.out.println("Home button");
                    mainFrame.switchToMainMenu();
                    return;

                case "Bookings":
                    //System.out.println("Bookings button");
                    mainFrame.switchToBooking();
                    return;

                case "Review Menu":
                    //System.out.println("Review Menu button");
                    return;

                case "Staff Tracking":
                    //System.out.println("Staff Tracking button");
                    mainFrame.switchToStaffTracking();
                    return;

                case "Sales":
                    //System.out.println("Sales button");
                    mainFrame.switchToSales();
                    return;

                case "Wine":
                    //System.out.println("Wine button");
                    mainFrame.switchToWine();
                    return;

                case "Order Ingredients":
                    //System.out.println("Order Ingredients button");
                    mainFrame.switchToOrderIngredients();
                    return;
            }
        });

        return button;

    }

    public void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ReviewMenuGUI reviewMenuGUI = new ReviewMenuGUI(this.mainFrame);
            reviewMenuGUI.setVisible(true);
        });
    }
}