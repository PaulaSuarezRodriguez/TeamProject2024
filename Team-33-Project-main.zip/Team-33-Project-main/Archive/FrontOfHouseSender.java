import java.time.DayOfWeek;
import java.util.List;
import java.util.Map;

public class FrontOfHouseSender implements IFrontOfHouseSender {

    @Override
    public void sendUpdatedMenus(FrontOfHouseMenu menus) {

    }
    @Override
    public void sendWeeklyAverageBookings(Map<DayOfWeek, Integer> averageBookings) {

    }

}
