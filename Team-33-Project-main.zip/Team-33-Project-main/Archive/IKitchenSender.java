import java.util.List;

public interface IKitchenSender {
    void sendUpdatedMenus(FrontOfHouseMenu menus);
    void sendIngredientsList(SupplierIngredients ingredient);
}
