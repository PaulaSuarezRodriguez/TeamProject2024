import java.util.ArrayList;
import java.util.Arrays;

public class KitchenServiceReciever implements IKitchenReciever {
    @Override
    public Menu getCurrentMenu() {
        // Implementation to return the current menu
        return new Menu(new ArrayList<>()); // Placeholder for actual menu data
    }

    @Override
    public Dish getDishDetails(int dishId) {
        // Implementation to return details of a specific dish
        return new Dish(dishId, "Sample Dish", Arrays.asList("Ingredient 1", "Ingredient 2"), Arrays.asList("Allergen 1"));
    }
}