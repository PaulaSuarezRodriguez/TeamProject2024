import java.sql.*;

public class SommelierBook {
    private int wineID = 0;
    private String name;
    private int year;
    private int quantity;

    public SommelierBook(int wineID, String name, int year, int quantity){
        this.name = name;
        this.wineID = wineID;
        this.year = year;
        this.quantity = quantity;
    }

    //Getters and setters for wine attributes
    public int getWineID() {
        return wineID;
    }

    public void setWineID(int wineID) {
        this.wineID = wineID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public void addWine(int wineID, String name, int year, int quantity) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            //Establish connection to the DB
            connection = JDBConnection.getConnection();

            //Prepare SQL statement
            String query = "INSERT INTO SommelierBook (wine_ID, Name, Year, StockQuantity) VALUES (?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, wineID);
            preparedStatement.setString(2, name);
            preparedStatement.setInt(3, year);
            preparedStatement.setInt(4, quantity);

            //Execute
            preparedStatement.executeUpdate();
            System.out.println("Wine added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBConnection.closeStatement(preparedStatement);
            JDBConnection.closeConnection(connection);
        }
    }

    public void readWine(){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try{
            //Establish a connection to DB
            connection = JDBConnection.getConnection();

            //Prepare the SQL query
            String query = "SELECT * FROM SommelierBook";
            preparedStatement = connection.prepareStatement(query);

            //Execute
            resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                System.out.println("Wine ID: "+resultSet.getInt(1)+ ", Name: " + resultSet.getString(2)+ ", Year: " + resultSet.getInt(3)+", Quantity: " + resultSet.getInt(4));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            JDBConnection.closeConnection(connection);
            JDBConnection.closeStatement(preparedStatement);
            JDBConnection.closeResult(resultSet);
        }

    }

    public void deleteWine(int wineID){
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            //Establish connection
            connection = JDBConnection.getConnection();

            //Prepare SQL statement
            String query = "DELETE FROM SommelierBook WHERE wine_ID = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, wineID);

            //Execute
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Wine with ID " + wineID + " deleted successfully.");
            } else {
                System.out.println("No wine found with ID " + wineID + ". No rows deleted.");
            }
        }catch (SQLException e) {
            throw new RuntimeException(e);
        }finally {
            JDBConnection.closeConnection(connection);
            JDBConnection.closeStatement(preparedStatement);
        }
    }

    public static void main(String[] args) {
        //Sample wine data
        int wineIDs = 1;
        String name = "Chardonnay";
        int year = 2023;
        int quantity = 10;

        //Create an instance of SommelierBook
        SommelierBook sommelierBook = new SommelierBook(wineIDs, name, year, quantity);

        //Deletes coloumn 1 with ID 1
        sommelierBook.deleteWine(1);
        //Adds to coloumn 1
        sommelierBook.addWine(wineIDs, name, year, quantity);
        //Prints the wine table
        sommelierBook.readWine();

    }
}

