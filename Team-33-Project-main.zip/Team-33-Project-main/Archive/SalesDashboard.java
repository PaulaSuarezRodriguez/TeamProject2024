import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class SalesDashboard extends JFrame {
    // Define color palette
    private static final Color COLOR_DARK_GRAY = new Color(50, 50, 50);
    private static final Color COLOR_LIGHT_GRAY = new Color(75, 75, 75);
    private static final Color COLOR_TEXT = Color.WHITE;
    private static JLabel todaysCostLabel;
    private static JLabel todaysSalesLabel;
    private static JLabel totalSalesLabel;

    private static JLabel favoriteDishesLabel;
    private JFormattedTextField startDateField, endDateField;
    private JPanel graphPanel;

    private static final Color BUTTON_LIGHT = new Color(180, 180, 180);

    private static final Color COLOR_BACKGROUND = new Color(42, 52, 54);
    private static final Color COLOR_WHITE = new Color(255, 255, 255);

    private JLabel graphTitle;

    private Map<String, Integer> monthlySalesData = getMonthlySalesData();
    private Map<String, Integer> yearlySalesData = getYearlySalesData();
    private static final Font titleFont = new Font("Helvetica", Font.BOLD, 18);

    private String graphState = "monthly";
    private String graphTitleState = "Monthly Bookings";
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public SalesDashboard() {
        setTitle("Lancaster's Dashboard");
        setSize(1200, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(COLOR_DARK_GRAY);

        JPanel sidebar = createSidebar();
        add(sidebar, BorderLayout.WEST);

        JPanel contentArea = new JPanel(null);
        contentArea.setBackground(COLOR_DARK_GRAY);

        JPanel todaysSalesCard = new JPanel();
        todaysSalesCard.setBounds(150, 100, 250, 100);
        todaysSalesCard.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(todaysSalesCard);
        todaysSalesLabel = createCard(null, null, todaysSalesCard);


        JPanel todaysCostPanel = new JPanel(); // Container for the card
        todaysCostPanel.setBounds(450, 100, 250, 100);
        todaysCostPanel.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(todaysCostPanel);
        todaysCostLabel = createCard(null, null, todaysCostPanel);


        JPanel totalSalesCard = new JPanel();
        totalSalesCard.setBounds(750, 100, 250, 100);
        totalSalesCard.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(totalSalesCard);
        totalSalesLabel = createCard(null, null, totalSalesCard);


        JPanel favoriteDishesCard = new JPanel();
        favoriteDishesCard.setLayout(new BorderLayout()); 
        favoriteDishesCard.setBounds(725, 250, 250, 400);
        favoriteDishesCard.setBackground(COLOR_LIGHT_GRAY);
        JLabel bestDishesLabel = new JLabel("BEST DISHES", SwingConstants.CENTER);
        bestDishesLabel.setForeground(COLOR_TEXT);
        bestDishesLabel.setFont(new Font("Serif", Font.BOLD, 16));
        bestDishesLabel.setBackground(COLOR_LIGHT_GRAY);
        bestDishesLabel.setOpaque(true);
        favoriteDishesCard.add(bestDishesLabel, BorderLayout.NORTH);
        favoriteDishesLabel = createCard(null, null, favoriteDishesCard );
        favoriteDishesCard.add(bestDishesLabel, BorderLayout.NORTH);
        contentArea.add(favoriteDishesCard, BorderLayout.NORTH);

        JPanel datePanel = createDatePanel();
        datePanel.setBounds(725, 660, 250, 100);
        datePanel.setBackground(COLOR_LIGHT_GRAY);
        contentArea.add(datePanel);


        graphTitle = new JLabel(graphTitleState, SwingConstants.CENTER);
        graphTitle.setFont(titleFont);
        graphTitle.setForeground(COLOR_TEXT);
        graphTitle.setBounds(30, 250, 800, 30);
        contentArea.add(graphTitle);
        graphPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (graphState == "monthly") {
                    drawBarChart(g, monthlySalesData, graphState);
                }
                else if (graphState == "yearly") {
                    drawBarChart(g, yearlySalesData, graphState);
                }
            }
        };

        graphPanel.setBounds(150, 290, 500, 400);
        graphPanel.setBackground(COLOR_BACKGROUND);
        contentArea.add(graphPanel);

        JButton monthlyGraphButton = new JButton("Monthly Button");
        monthlyGraphButton.addActionListener(e -> {
            //System.out.println("Monthly Button");
            graphState = "monthly";
            graphTitleState = "Monthly Sales";
            graphTitle.setText(graphTitleState);
            monthlySalesData = getMonthlySalesData();
            //System.out.println(monthlyBookingsData);
            graphPanel.repaint();
            graphTitle.repaint();
        });

        monthlyGraphButton.setBounds(150, 700, 200, 35);
        monthlyGraphButton.setBackground(BUTTON_LIGHT);
        monthlyGraphButton.setFocusPainted(false);
        monthlyGraphButton.setBorderPainted(false);
        monthlyGraphButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                monthlyGraphButton.setBackground(COLOR_WHITE.brighter());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                monthlyGraphButton.setBackground(BUTTON_LIGHT);
            }
        });
        contentArea.add(monthlyGraphButton);

        JButton yearlyGraphButton = new JButton("Yearly Button");
        yearlyGraphButton.addActionListener(e -> {
            //System.out.println("Yearly Button");
            graphState = "yearly";
            graphTitleState = "Yearly Sales";
            graphTitle.setText(graphTitleState);
            yearlySalesData = getYearlySalesData();
            //System.out.println(yearlyBookingsData);
            graphPanel.repaint();
            graphTitle.repaint();
        });

        yearlyGraphButton.setBounds(450, 700, 200, 35);
        yearlyGraphButton.setBackground(BUTTON_LIGHT);
        yearlyGraphButton.setFocusPainted(false);
        yearlyGraphButton.setBorderPainted(false);
        yearlyGraphButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                yearlyGraphButton.setBackground(COLOR_WHITE.brighter());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                yearlyGraphButton.setBackground(BUTTON_LIGHT);
            }
        });
        contentArea.add(yearlyGraphButton);

        add(contentArea, BorderLayout.CENTER);
        calculateAndPrintTotalCost();
        calculateAndDisplayTotalSales();
        calculateTotalSalesOfAllTime();

    }

    private void drawBarChart(Graphics g, Map<String, Integer> data, String state) {
        int panelWidth = graphPanel.getWidth();
        int panelHeight = graphPanel.getHeight();

        Font numbersFont = new Font("Helvetica", Font.BOLD, 13); // Set a readable font size
        g.setFont(numbersFont);

        // Find the maximum count value for scaling bar heights
        int maxCount = Collections.max(data.values());

        // Calculate the y position for the bottom of the bars based on the panel height
        int yBottom = panelHeight - 50; // Leave some space at the bottom for labels

        // Y-axis position
        int yAxisX = 0; // You may adjust this value as needed
        int yAxisTop = 50; // Y position for the top of the Y-axis
        int yAxisBottom = panelHeight - 50; // Y position for the bottom of the Y-axis, matching the X-axis

        // Draw Y-axis line
        g.setColor(Color.WHITE);
        g.drawLine(yAxisX, yAxisTop, yAxisX, yAxisBottom);

        // Calculate the width of each bar and the spacing based on the panel width and number of data points
        int numberOfBars = data.size();
        int spacing = 10; // Adjust the spacing as needed
        int totalSpacing = (numberOfBars - 1) * spacing; // Total spacing between bars
        int barWidth = (panelWidth - totalSpacing) / numberOfBars;


        for (int i = 0; i < numberOfBars; i++) {
            String key = (String) data.keySet().toArray()[i];
            int count = data.get(key);

            // Scale the height of the bar to fit within the panel bounds
            int barHeight = (int) (((double) count / maxCount) * (panelHeight - 100)); // 100 pixels reserved for top and bottom margins

            // Set the x position for the current bar
            int x = i * (barWidth + spacing);

            // Draw the bar
            g.setColor(Color.WHITE); // Bar color
            g.fillRect(x, yBottom - barHeight, barWidth, barHeight);

            // Draw the value of the bar
            g.setColor(COLOR_DARK_GRAY); // Choose a color that contrasts with the bar's color
            String valueString = Integer.toString(count);
            int stringWidth = g.getFontMetrics().stringWidth(valueString);

            // Calculate the position of the string.
            // If the bar is not tall enough, draw the string above the bar instead.
            int stringY = yBottom - barHeight + g.getFontMetrics().getAscent();
            if (barHeight < g.getFontMetrics().getHeight() + 2) {
                stringY = yBottom - barHeight - g.getFontMetrics().getHeight();
                g.setColor(COLOR_DARK_GRAY); // Change the color to contrast with the background
            }

            int stringX = x + (barWidth / 2 - stringWidth / 2); // Center the string within the bar
            g.drawString(valueString, stringX, stringY);

            // Draw the label below the bar
            g.setColor(Color.WHITE);
            g.drawString(key, x + (barWidth / 2 - g.getFontMetrics().stringWidth(key) / 2), yBottom + 15); // Center the label below the bar
        }

        // Draw the axis line at the bottom
        g.setColor(Color.WHITE);
        g.drawLine(0, yBottom, panelWidth, yBottom);
    }

    private Map<String, Integer> getMonthlySalesData() {
        Map<String, Integer> monthlySalesMap = new LinkedHashMap<>();
        String query = "SELECT DATE_FORMAT(SaleDate, '%Y-%m') AS MonthYear, SUM(D.Price * DS.QuantitySold) AS SalesTotal " +
                "FROM DailySales DS " +
                "JOIN Dishes D ON DS.Dish_ID = D.Dish_ID " +
                "GROUP BY MonthYear " +
                "ORDER BY SaleDate ASC;";

        try (Connection conn = JDBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String monthYear = rs.getString("MonthYear");
                int total = rs.getInt("SalesTotal");
                monthlySalesMap.put(monthYear, total);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return monthlySalesMap;
    }

    private Map<String, Integer> getYearlySalesData() {
        Map<String, Integer> yearlySalesMap = new LinkedHashMap<>();
        String query = "SELECT YEAR(SaleDate) AS Year, SUM(D.Price * DS.QuantitySold) AS SalesTotal " +
                "FROM DailySales DS " +
                "JOIN Dishes D ON DS.Dish_ID = D.Dish_ID " +
                "GROUP BY Year " +
                "ORDER BY SaleDate ASC;";

        try (Connection conn = JDBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String year = rs.getString("Year");
                int total = rs.getInt("SalesTotal");
                yearlySalesMap.put(year, total);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return yearlySalesMap;
    }


    private JPanel createGraphCard(String title, String content) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(COLOR_LIGHT_GRAY);
        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setForeground(COLOR_TEXT);
        card.add(titleLabel, BorderLayout.NORTH);
        JLabel contentLabel = new JLabel(content, SwingConstants.CENTER);
        contentLabel.setForeground(COLOR_TEXT);
        card.add(contentLabel, BorderLayout.CENTER);
        //card.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        return card;
    }

    private JPanel createDatePanel() {
        JPanel datePanel = new JPanel();
        datePanel.setLayout(new BoxLayout(datePanel, BoxLayout.Y_AXIS));
        datePanel.setBackground(Color.BLACK);

        // Start Date components
        JPanel startDatePanel = new JPanel();
        startDatePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        startDatePanel.setBackground(COLOR_LIGHT_GRAY);
        JLabel startDateLabel = new JLabel("Start Date:");
        startDateLabel.setForeground(Color.WHITE);
        startDateField = new JFormattedTextField(dateFormat);
        startDateField.setColumns(10);
        startDatePanel.add(startDateLabel);
        startDatePanel.add(startDateField);

        // End Date components
        JPanel endDatePanel = new JPanel();
        endDatePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        endDatePanel.setBackground(COLOR_LIGHT_GRAY);
        JLabel endDateLabel = new JLabel("End Date:");
        endDateLabel.setForeground(Color.WHITE);
        endDateField = new JFormattedTextField(dateFormat);
        endDateField.setColumns(10);
        endDatePanel.add(endDateLabel);
        endDatePanel.add(endDateField);

        // Query Button
        JButton queryButton = new JButton("Query");
        queryButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        queryButton.addActionListener(e -> calculateBestToWorstDishesFromDate(startDateField.getText(), endDateField.getText()));


        datePanel.add(startDatePanel);
        datePanel.add(endDatePanel);
        datePanel.add(queryButton);

        return datePanel;
    }


    public void calculateBestToWorstDishesFromDate(String startDate, String endDate) {
        try (Connection con = JDBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT D.Name, SUM(DS.QuantitySold) AS TotalSold " +
                             "FROM DailySales DS " +
                             "JOIN Dishes D ON DS.Dish_ID = D.Dish_ID " +
                             "WHERE DS.SaleDate BETWEEN '" + startDate + "' AND '" + endDate + "' " +
                             "GROUP BY DS.Dish_ID " +
                             "ORDER BY TotalSold DESC")) {

            StringBuilder result = new StringBuilder("<html><body style='text-align:left;'>");
            while (rs.next()) {
                result.append(String.format(
                        "<div style='margin:5px;'>" +
                                "<span style='font-weight:bold;color:#FFD700;'>%s:</span> " +
                                "<span style='color:white;'>%d sold</span>" +
                                "</div>",
                        rs.getString("Name"), rs.getInt("TotalSold")));
            }
            result.append("</body></html>");
            favoriteDishesLabel.setText(result.toString());
            favoriteDishesLabel.setVerticalAlignment(SwingConstants.TOP);
        } catch (SQLException e) {
            e.printStackTrace();
            favoriteDishesLabel.setText("Failed to calculate best-selling dish.");
        }
    }

    public void calculateTotalSalesOfAllTime() {
        try (Connection con = JDBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT SUM(D.Price * DS.QuantitySold) AS TotalSales " +
                             "FROM DailySales DS " +
                             "JOIN Dishes D ON DS.Dish_ID = D.Dish_ID")) {

            if (rs.next()) {
                double totalSales = rs.getDouble("TotalSales");
                SwingUtilities.invokeLater(() -> {
                    String htmlText = String.format(
                            "<html>" +
                                    "<div style='font-size:13px;font-family:Serif; font-weight:bold; text-align: center;color: white;'>Total Sales of All Time</div>" +
                                    "<div style='font-size:14px;font-family:Serif; font-weight:bold; text-align: center; color: white;'>$%.2f</div>" +
                                    "</html>", totalSales);
                    totalSalesLabel.setText(htmlText); // Assuming you want to display it in todaysSalesLabel
                });
            } else {
                SwingUtilities.invokeLater(() -> {
                    totalSalesLabel.setText("No sales data found.");
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> {
                totalSalesLabel.setText("Failed to calculate total sales.");
            });
        }
    }

    public void calculateAndDisplayTotalSales() {
        // Attempt to connect to the database and calculate total sales for the latest date
        try (Connection con = JDBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT DS.SaleDate, SUM(D.Price * DS.QuantitySold) AS TotalSales " +
                             "FROM DailySales DS " +
                             "JOIN Dishes D ON DS.Dish_ID = D.Dish_ID " +
                             "WHERE DS.SaleDate = (SELECT MAX(SaleDate) FROM DailySales) " +
                             "GROUP BY DS.SaleDate" )) {

            if (rs.next()) {
                double totalSales = rs.getDouble("TotalSales");
                String saleDate = rs.getString("SaleDate"); // Get the most recent sale date
                SwingUtilities.invokeLater(() -> {
                    String htmlText = String.format(
                            "<html>" +
                                    "<div style='font-size:13px;font-family:Serif; font-weight:bold; text-align: center;color: white;'>Total Sales for %s</div>" + // Title styling with date
                                    "<div style='font-size:14px;font-family:Serif; font-weight:bold; text-align: center; color: white;'>$%.2f</div>" + // Sales amount styling
                                    "</html>", saleDate, totalSales);
                    todaysSalesLabel.setText(htmlText);
                });
            } else {
                SwingUtilities.invokeLater(() -> {
                    todaysSalesLabel.setText("No sales data found.");
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> {
                todaysSalesLabel.setText("Failed to calculate total sales.");
            });
        }
    }
    public void calculateAndPrintTotalCost() {
        int orderId = findLatestOrderId();
        // Attempt to connect to the database, query the total cost, and print it
        try (Connection con = JDBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT SUM(i.Price * io.Quantity) AS TotalCost " +
                     "FROM IngredientOrders io " +
                     "JOIN Ingredient i ON io.Ingredient_ID = i.Ingredient_ID " +
                     "WHERE io.Order_ID = " + orderId)) {

            if (rs.next()) {
                double totalCost = rs.getDouble("TotalCost");
                SwingUtilities.invokeLater(() -> {
                    String htmlText = String.format(
                            "<html>" +
                                    "<div style='font-size:14px;font-family:Serif; font-weight:bold; text-align: center; color: white;'>Today's Cost</div>" + // Title styling
                                    "<div style='font-size:14px;font-family:Serif; font-weight:bold; text-align: center; color: white;'>$%.2f</div>" + // Price styling
                                    "</html>", totalCost);
                    todaysCostLabel.setText(htmlText);
                });
            } else {
                SwingUtilities.invokeLater(() -> {
                    todaysCostLabel.setText("No data found.");
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            SwingUtilities.invokeLater(() -> {
                todaysCostLabel.setText("Failed to calculate cost");
            });
        }
    }

    private int findLatestOrderId() {
        try (Connection con = JDBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT MAX(Order_ID) AS LatestOrderID FROM Orders")) {
            if (rs.next()) {
                return rs.getInt("LatestOrderID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Return -1 if not found or an error occurs
    }

    private JLabel createCard(String title, String content, JPanel panelContainer) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(COLOR_LIGHT_GRAY);

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setForeground(COLOR_TEXT);
        card.add(titleLabel, BorderLayout.NORTH);

        JLabel contentLabel = new JLabel(content, SwingConstants.CENTER);
        contentLabel.setForeground(COLOR_TEXT);
        card.add(contentLabel, BorderLayout.CENTER);

        card.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panelContainer.add(card);
        return contentLabel;
    }

    private JPanel createCard(String title, String content) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(COLOR_LIGHT_GRAY);
        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setForeground(COLOR_TEXT);
        card.add(titleLabel, BorderLayout.NORTH);
        JLabel contentLabel = new JLabel(content, SwingConstants.CENTER);
        contentLabel.setForeground(COLOR_TEXT);
        card.add(contentLabel, BorderLayout.CENTER);
        card.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        return card;
    }


    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(COLOR_LIGHT_GRAY);
        sidebar.add(createMenuLabel("Home"));
        sidebar.add(createMenuLabel("Bookings"));
        sidebar.add(createMenuLabel("Review Menu"));
        sidebar.add(createMenuLabel("Staff Tracking"));
        sidebar.add(createMenuLabel("Sales"));
        sidebar.add(createMenuLabel("Order Ingredients"));
        return sidebar;
    }

    private JLabel createMenuLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(COLOR_TEXT);
        label.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        label.setHorizontalAlignment(SwingConstants.LEFT);
        Dimension labelSize = new Dimension(200, 75);
        label.setMaximumSize(labelSize);
        return label;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SalesDashboard dashboard = new SalesDashboard();
            dashboard.setVisible(true);
        });
    }
}