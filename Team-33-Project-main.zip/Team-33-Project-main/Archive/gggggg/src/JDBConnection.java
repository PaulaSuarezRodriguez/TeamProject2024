import java.sql.*;

public class JDBConnection {

    private static final String URL = "jdbc:mysql://smcse-stuproj00.city.ac.uk:3306/in2033t33";
    private static final String USERNAME = "in2033t33_a";
    private static final String PASSWORD = "15WzpldHAsU";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    public static void closeConnection(Connection connection) { //closing the connection to the database.
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void closeStatement(Statement statement){ //closing the statement object
        if(statement != null){
            try{
                statement.close();
            }catch(SQLException e){
                e.printStackTrace();
            }
        }
    }

    public static void closeResult(ResultSet resultSet){ //closing the resultset object
        if(resultSet != null){
            try{
                resultSet.close();
            }
            catch(SQLException e){
                e.printStackTrace();
            }
        }
    }

// Below is the code that was first written where everything related to connecting, writing, and reading to and from the database  was in one place.
//    public static void main(String[] args) {
//        String url = "jdbc:mysql://smcse-stuproj00.city.ac.uk:3306/in2033t33";
//        String adminUsername = "in2033t33_a";
//        String adminPassword = "15WzpldHAsU";
//
//        try {
////            Class.forName("com.mysql.cj.jdbc.Driver");
//            Connection connection = DriverManager.getConnection(url,adminUsername,adminPassword);
//
//            Statement statement = connection.createStatement();
//
//            // If connection is successful, do something
//            if (connection != null) {
//                System.out.println("Connected to the database!");
//                // Perform your database operations here
//            } else {
//                System.out.println("Failed to make connection!");
//            }
//            ResultSet resultSet = statement.executeQuery("select * from Ingredient");
//
//            while(resultSet.next()){
//                System.out.println(resultSet.getInt(1)+ " " + resultSet.getString(2));
//            }
//            statement.close();
//            resultSet.close();
//            connection.close();
//
//
//        }
//        catch(Exception e){
//            System.out.println(e);
//        }
//
//    }
}
