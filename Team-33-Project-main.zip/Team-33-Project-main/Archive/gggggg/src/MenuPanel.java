import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class MenuPanel extends JFrame {
    private JPanel startersPanel;
    private JPanel mainsPanel;
    private JPanel secondPanel;
    private JPanel dessertsPanel;


    public MenuPanel() {

        ImageIcon image = new ImageIcon("src/logoRoot.png");
        setIconImage(image.getImage());


        setTitle("Lancaster Menu");
        setSize(1200, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);


        setLayout(new BorderLayout());

        SidebarPanel sidebar = new SidebarPanel();
        add(sidebar, BorderLayout.WEST);

        customizeLookAndFeel();

        JPanel mainContentPanel = createMainContentPanel();
        add(new JScrollPane(mainContentPanel), BorderLayout.CENTER);
        add(createButtonPanel(), BorderLayout.SOUTH);

        setVisible(true);
    }

    private JPanel createMainContentPanel() {
        JPanel mainContentPanel = new JPanel();
        mainContentPanel.setLayout(new BoxLayout(mainContentPanel, BoxLayout.Y_AXIS));

        JLabel titleLabel = new JLabel("MENU", SwingConstants.CENTER);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBackground(new Color(42,52,54,255));
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 24)); // Set a larger font size for the title

        mainContentPanel.add(titleLabel, BorderLayout.CENTER);
        mainContentPanel.setBackground(new Color(42,52,54,255));

        Font defaultFont = new Font("SansSerif", Font.PLAIN, 16);
        Color defaultColor = Color.WHITE;

        startersPanel = createSectionPanel("Starters", defaultColor, defaultFont);
        startersPanel.setBackground(new Color(42,52,54,255));
        mainsPanel = createSectionPanel("Main Courses", defaultColor, defaultFont);
        mainsPanel.setBackground(new Color(42,52,54,255));
        secondPanel = createSectionPanel("Second Courses", defaultColor, defaultFont);
        secondPanel.setBackground(new Color(42,52,54,255));
        dessertsPanel = createSectionPanel("Desserts", defaultColor, defaultFont);
        dessertsPanel.setBackground(new Color(42,52,54,255));

//        JPanel sommelierBookPanel = createSectionPanel("Sommelier Book");

        mainContentPanel.add(startersPanel);
        mainContentPanel.add(mainsPanel);
        mainContentPanel.add(secondPanel);
        mainContentPanel.add(dessertsPanel);
//        mainContentPanel.add(sommelierBookPanel);
//        loadWines(sommelierBookPanel);
        mainContentPanel.add(createAllergenLegend());

        return mainContentPanel;
    }

    private JPanel createSectionPanel(String title, Color titleColor, Font titleFont) {
        JPanel sectionPanel = new JPanel();
        sectionPanel.setBackground(new Color(115, 116, 124));
        sectionPanel.setLayout(new BoxLayout(sectionPanel, BoxLayout.Y_AXIS));

        // Create a JLabel to use as a custom title
        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setForeground(titleColor);
        titleLabel.setFont(titleFont);
        titleLabel.setHorizontalAlignment(JLabel.CENTER); // Ensure it is centered horizontally
        titleLabel.setVerticalAlignment(JLabel.CENTER); // Ensure it is centered vertically


        // Create an empty border for padding around the label
        Border paddingBorder = new EmptyBorder(10, 10, 10, 10);
        titleLabel.setBorder(paddingBorder);

        // Add the custom title label to the panel
        sectionPanel.add(titleLabel);

        // Create a titled border with empty title (since JLabel is used as the title)
        Border border = BorderFactory.createTitledBorder("");
        Border marginBorder = new EmptyBorder(10, 10, 10, 10);
        sectionPanel.setBorder(new CompoundBorder(border, marginBorder));

        return sectionPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel();


        JButton addButton = new JButton("Add Dish");
        addButton.addActionListener(e -> addDish());
        customizeButtonLogin(addButton);


        JButton editButton = new JButton("Edit Dish");
//        editButton.addActionListener(e -> editOrDeleteDish());
        customizeButtonLogin(editButton);

        JButton saveButton = new JButton("SAVE");
//        saveButton.addActionListener(e -> saveMenu());
        customizeButtonLogin(saveButton);


        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(saveButton);
        return buttonPanel;
    }

    private void addDish() {
        String[] options = {"Starters", "Main Courses", "Second Courses", "Desserts"};
        String type = (String) JOptionPane.showInputDialog(null, "Choose the type of dish:",
                "Dish Type", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        if (type != null && type.length() > 0) {
            Map<Integer, String> dishes = fetchDishes();
            Integer[] dishIds = dishes.keySet().toArray(new Integer[0]);
            String selectedDishName = (String) JOptionPane.showInputDialog(null, "Select a Dish:",
                    "Select Dish", JOptionPane.QUESTION_MESSAGE, null, dishes.values().toArray(new String[0]),
                    dishes.values().toArray(new String[0])[0]);

            if (selectedDishName != null) {
                Optional<Integer> selectedDishId = dishes.entrySet().stream()
                        .filter(entry -> entry.getValue().equals(selectedDishName))
                        .map(Map.Entry::getKey)
                        .findFirst();

                selectedDishId.ifPresent(id -> {
                    // Select allergens for the dish
                    JPanel allergenPanel = new JPanel(new GridLayout(0, 4));
                    for (Allergen allergen : Allergen.values()) {
                        JCheckBox checkBox = new JCheckBox(allergen.name());
                        allergenPanel.add(checkBox);
                    }

                    int result = JOptionPane.showConfirmDialog(this, allergenPanel, "Select Allergens",
                            JOptionPane.OK_CANCEL_OPTION);
                    if (result == JOptionPane.OK_OPTION) {
                        Set<Allergen> selectedAllergens = new HashSet<>();
                        for (int i = 0; i < allergenPanel.getComponentCount(); i++) {
                            JCheckBox checkBox = (JCheckBox) allergenPanel.getComponent(i);
                            if (checkBox.isSelected()) {
                                selectedAllergens.add(Allergen.valueOf(checkBox.getText()));
                            }
                        }

                        Dish dish = fetchDishFromDatabase(id); // No allergen fetching from the database
                        if (dish != null) {
                            String suggestedWine = selectWine();

                            // Temporarily assign allergens for display
                            dish.setAllergens(selectedAllergens);

                            addDishToPanel(dish, type, suggestedWine);

                            // Optionally clear allergens after adding to panel
                            dish.setAllergens(null);
                        } else {
                            JOptionPane.showMessageDialog(this, "Dish not found");
                        }
                    }
                });
            }
        }
    }


    private Map<Integer, String> fetchDishes() {
        Map<Integer, String> dishes = new LinkedHashMap<>();
        try (Connection conn = JDBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT Dish_ID, Name FROM Dishes");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                dishes.put(rs.getInt("Dish_ID"), rs.getString("Name"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
            e.printStackTrace();
        }
        return dishes;
    }


    private String selectWine() {
        try (Connection conn = JDBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT Wine_ID, Name, Year FROM SommelierBook");
             ResultSet rs = stmt.executeQuery()) {
            Map<String, String> wines = new LinkedHashMap<>();
            while (rs.next()) {
                String wineDetails = rs.getString("Name") + " (" + rs.getString("Year") + ")";
                wines.put(String.valueOf(rs.getInt("Wine_ID")), wineDetails);
            }
            String[] wineArray = wines.values().toArray(new String[0]);
            String selectedWine = (String) JOptionPane.showInputDialog(null, "Select a wine that pairs well:",
                    "Select Wine", JOptionPane.QUESTION_MESSAGE, null, wineArray, wineArray[0]);
            return selectedWine;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    private void addDishToPanel(Dish dish, String type, String suggestedWine) {
        // Labels for dish details
        String allergenLabelText = "";
        for (Allergen allergen : dish.getAllergens()) {
            allergenLabelText += "<span style='color:" + "; font-size: 8px;'> (" + allergen.getCode() + ")</span>";
        }
        JLabel nameLabel = new JLabel("<html>" + dish.getName() + allergenLabelText + "</html>");
        nameLabel.setFont(new Font("Tahoma", Font.BOLD, 18)); // font and size

        JLabel wineLabel = new JLabel("Suggested wine: " + suggestedWine);
        wineLabel.setFont(new Font("Serif", Font.ITALIC, 12));  // font and size
        JLabel descriptionLabel = new JLabel("<html><body style='width: 200px'>" + dish.getDescription() + "</body></html>");
        descriptionLabel.setFont(new Font("Arial", Font.PLAIN, 16));  // font and size
        JLabel priceLabel = new JLabel("£" + String.format("%.2f", dish.getPrice()), SwingConstants.RIGHT);
        priceLabel.setFont(new Font("Arial", Font.PLAIN, 17)); // font and size

        // Panel for organizing the name, wine, and description vertically
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.add(nameLabel);
        textPanel.add(wineLabel);
        textPanel.add(descriptionLabel);


        // Main dish panel layout
        JPanel dishPanel = new JPanel(new BorderLayout());
        dishPanel.add(textPanel, BorderLayout.CENTER);
        dishPanel.add(priceLabel, BorderLayout.EAST);

        // Adding the dish panel to the appropriate section
        switch (type) {
            case "Starters":
                startersPanel.add(dishPanel);
                break;
            case "Main Courses":
                mainsPanel.add(dishPanel);
                break;
            case "Second Courses":
                secondPanel.add(dishPanel);
                break;
            case "Desserts":
                dessertsPanel.add(dishPanel);
                break;
        }
        revalidate();
        repaint();
    }



    private Dish fetchDishFromDatabase(int dishID) {
        try (Connection conn = JDBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT Dish_ID, Name, Description, Price FROM Dishes WHERE Dish_ID = ?")) {
            stmt.setInt(1, dishID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Dish(rs.getInt("Dish_ID"), rs.getString("Name"), rs.getString("Description"), rs.getDouble("Price"));

            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }


    private void customizeLookAndFeel() {
        UIManager.put("Panel.background", Color.decode("#f5f5f5"));
        UIManager.put("TitledBorder.titleColor", Color.decode("#2a2a2a"));
        UIManager.put("Label.font", new Font("SansSerif", Font.BOLD, 14));
        UIManager.put("Label.foreground", Color.decode("#333333"));
        UIManager.put("Button.background", Color.decode("#ffffff"));
        UIManager.put("Button.foreground", Color.decode("#000000"));
    }

    private JPanel createAllergenLegend() {
        JPanel legendPanel = new JPanel(new GridLayout(0, 4));
        legendPanel.setBorder(BorderFactory.createTitledBorder("Allergen Key"));

        for (Allergen allergen : Allergen.values()) {
            JLabel label = new JLabel("(" + allergen.getCode() + ") - " + allergen.name());

            legendPanel.add(label);
        }
        // Set a fixed vertical height
        Dimension preferredSize = legendPanel.getPreferredSize();
        preferredSize.height = 80; // Set your desired height here
        legendPanel.setPreferredSize(preferredSize);

        return legendPanel;
    }


    private void customizeButtonLogin(JButton button) {
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFocusPainted(false);
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.repaint();
            }
        });
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                JButton b = (JButton) c;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (b.getModel().isRollover()) {
                    g2.setColor(new Color(115, 116, 124));
                } else {
                    g2.setColor(new Color(160, 160, 160));
                }
                g2.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), 30, 30);
                g2.dispose();
                super.paint(g, c);
            }
        });



    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(MenuPanel::new);
    }



}






//METHOD IF WANT TO HAVE SOMMELIER BOOK ON THE MENU


//    private void loadWines(JPanel sommelierBookPanel) {
//        try (Connection conn = JDBConnection.getConnection();
//             PreparedStatement stmt = conn.prepareStatement("SELECT Wine_ID, Name, Year, StockQuantity FROM SommelierBook");
//             ResultSet rs = stmt.executeQuery()) {
//
//            while (rs.next()) {
//                String name = rs.getString("Name");
//                String year = rs.getString("Year");
//                int stockQuantity = rs.getInt("StockQuantity");
//
//                JLabel nameLabel = new JLabel(name);
//                JLabel yearLabel = new JLabel("Year: " + year);
//                JLabel stockLabel = new JLabel("Stock: " + stockQuantity + " bottles", SwingConstants.RIGHT);
//
//                JPanel winePanel = new JPanel(new BorderLayout());
//                winePanel.add(nameLabel, BorderLayout.NORTH);
//                winePanel.add(yearLabel, BorderLayout.CENTER);
//                winePanel.add(stockLabel, BorderLayout.EAST);
//
//                sommelierBookPanel.add(winePanel);
//            }
//        } catch (SQLException e) {
//            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }