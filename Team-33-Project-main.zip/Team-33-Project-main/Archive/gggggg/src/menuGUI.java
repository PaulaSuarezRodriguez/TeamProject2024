import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.OrientationRequested;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.print.PrinterException;
import java.sql.*;
import java.text.MessageFormat;


public class menuGUI extends JFrame {


    private JTable tableMenu;

    private DefaultTableModel tableModel;



    public menuGUI() {

        ImageIcon image = new ImageIcon("src/logoRoot.png");
        setIconImage(image.getImage());

        setTitle("Lancaster Menu Table");
        setSize(1200, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Add the reusable sidebar
        SidebarPanel sidebar = new SidebarPanel();
        add(sidebar, BorderLayout.WEST);

        // Create main panel with some padding to the left
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(42,52,54,255));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20)); // 20-pixel padding on the left
        mainPanel.add(createTitlePanel(), BorderLayout.NORTH);
        mainPanel.add(createTablePanel(), BorderLayout.CENTER);
        mainPanel.add(createButtonPanel(), BorderLayout.SOUTH);

        // Add main panel to frame
        add(mainPanel, BorderLayout.CENTER);

        // Set the frame visible
        setVisible(true);
    }

    private JPanel createTitlePanel() {
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(42,52,54,255));
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        JLabel titleLabel = new JLabel("REVIEW MENU");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Ensure it's centered in the BoxLayout
        titlePanel.add(titleLabel);
        titlePanel.add(Box.createRigidArea(new Dimension(0, 10))); // Add a 10-pixel vertical space
        return titlePanel;
    }

    private JScrollPane createTablePanel() {
        // Table model with column names

        tableModel = new DefaultTableModel(new String[]{"Dish ID", "Name", "Description", "Price"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;  // Make sure cells are not editable
//                return column != 0;
            }
        };


        tableMenu = new JTable(tableModel);  // Use tableMenu directly
        tableMenu.setFont(new Font("Serif", Font.PLAIN, 18)); // Increase font size
        tableMenu.setRowHeight(30); // Increase row height
        fetchDishesFromDB();  // Fetch data from database and populate table

        JScrollPane scrollPane = new JScrollPane(tableMenu);  // Use tableMenu here
        return scrollPane;
    }


    private JPanel createButtonPanel() {

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(new Color(42,52,54,255));

        JButton addButton = new JButton("ADD");
        customizeButtonLogin(addButton);
        addButton.addActionListener(e -> addRow());

        JButton deleteButton = new JButton("DELETE");
        customizeButtonLogin(deleteButton);
        deleteButton.addActionListener(e -> deleteRow());

        JButton editButton = new JButton("EDIT");
        customizeButtonLogin(editButton);
        editButton.addActionListener(e -> editRow());

        JButton saveButton = new JButton("SAVE");
        customizeButtonLogin(saveButton);
        saveButton.addActionListener(e ->saveTableAsPDF());

//                saveButton.addActionListener(e -> fetchDishesFromDB());



        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(saveButton);

        return buttonPanel;
    }

    public void fetchDishesFromDB(){

        try {
            Connection conn = JDBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Dishes");

            tableModel.setRowCount(0);
            while (rs.next()) {

                int dishID = rs.getInt("Dish_ID");
                String name = rs.getString("Name");
                String description = rs.getString("Description");
                float price = rs.getFloat("Price");
                tableModel.addRow(new Object[]{dishID, name, description, price});
            }
        } catch (SQLException e){
            e.printStackTrace();
        }

    }


    private void addRow() {
        // Get values for each field via input dialogs

        String id = JOptionPane.showInputDialog(this, "Enter ID:");
        String name = JOptionPane.showInputDialog(this, "Enter Name:");
        String description = JOptionPane.showInputDialog(this, "Enter Description:");
        String price = JOptionPane.showInputDialog(this, "Enter Price:");


        // Validate and convert data as necessary
        if (id != null && name != null && description != null && price != null) {
            try {
                int idVal = Integer.parseInt(id);  // Convert ID from String to int
                double priceVal = Double.parseDouble(price);  // Validate price as a double
                tableModel.addRow(new Object[]{idVal, name, description, priceVal});
                addDish(idVal, name, description, priceVal);

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid input for price. Please enter a valid number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }


    public void addDish(int dishID, String name, String description, double price) {

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = JDBConnection.getConnection();

            String query = "INSERT INTO Dishes (Dish_ID, Name, Description, Price) VALUES (?, ?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, dishID);
            stmt.setString(2, name);
            stmt.setString(3, description);
            stmt.setDouble(4, price);

            stmt.executeUpdate();
            System.out.println("Dish added successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBConnection.closeStatement(stmt);
            JDBConnection.closeConnection(conn);
        }
    }


    private void deleteRow() {
        int selectedRow = tableMenu.getSelectedRow();
        System.out.println("Selected Row: " + selectedRow);  // Debug: print selected row index
        if (selectedRow >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete the selected dish?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                int dishID = (int) tableModel.getValueAt(selectedRow, 0);  // Ensure you are casting to the correct type
                if (deleteDish(dishID)) {
                    tableModel.removeRow(selectedRow);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean deleteDish(int dishID) {
        Connection conn = null;
        PreparedStatement stmt = null;
        boolean success = false;

        try {
            conn = JDBConnection.getConnection();
            String query = "DELETE FROM Dishes WHERE Dish_ID = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, dishID);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(this, "Dish deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                success = true;
            } else {
                JOptionPane.showMessageDialog(this, "No dish found with the specified ID.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error deleting dish: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } finally {
            JDBConnection.closeStatement(stmt);
            JDBConnection.closeConnection(conn);
        }
        return success;
    }

    private void editRow() {
        int selectedRow = tableMenu.getSelectedRow();
        int selectedColumn = tableMenu.getSelectedColumn();
        if (selectedRow == -1 || selectedColumn == -1) {
            JOptionPane.showMessageDialog(this, "Please select a cell to edit.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Object currentValue = tableModel.getValueAt(selectedRow, selectedColumn);
        String input = JOptionPane.showInputDialog(this, "Edit the value:", currentValue);
        if (input != null && !input.equals(currentValue)) {
            // Validate and update the cell value
            if (validateInput(selectedColumn, input)) {
                tableModel.setValueAt(input, selectedRow, selectedColumn);
                updateDatabase(selectedRow);
            }
        }
    }

    private boolean validateInput(int column, String input) throws NumberFormatException, IllegalArgumentException {
        switch (column) {
            case 0: // Dish ID - Normally you wouldn't allow editing this
                Integer.parseInt(input);
                break;
            case 3: // Price
                Double.parseDouble(input);
                break;
            case 1: // Name
            case 2: // Description
                if (input.trim().isEmpty()) {
                    throw new IllegalArgumentException("This field cannot be empty.");
                }
                break;
            default:
                return true;
        }
        return true;
    }


    private void updateDatabase(int row) {
        int dishID = Integer.parseInt(tableModel.getValueAt(row, 0).toString());
        String name = tableModel.getValueAt(row, 1).toString();
        String description = tableModel.getValueAt(row, 2).toString();
        double price = Double.parseDouble(tableModel.getValueAt(row, 3).toString());

        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = JDBConnection.getConnection();
            String query = "UPDATE Dishes SET Name = ?, Description = ?, Price = ? WHERE Dish_ID = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, name);
            stmt.setString(2, description);
            stmt.setDouble(3, price);
            stmt.setInt(4, dishID);

            stmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error updating dish: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            JDBConnection.closeStatement(stmt);
            JDBConnection.closeConnection(conn);
        }
    }

    public void saveTableAsPDF() {
        MessageFormat header = new MessageFormat("Menu Table");
        MessageFormat footer = new MessageFormat("Dishes Table");
        try {
            PrintRequestAttributeSet set = new HashPrintRequestAttributeSet();
            set.add(OrientationRequested.PORTRAIT);
            tableMenu.print(JTable.PrintMode.FIT_WIDTH, header, footer, true, set, true);
            JOptionPane.showMessageDialog(null, "Dishes Table created.", "Success", JOptionPane.INFORMATION_MESSAGE);

        }catch (PrinterException e){
            JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }



    private void customizeButtonLogin(JButton button) {
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFocusPainted(false);
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.repaint();
            }
        });
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                JButton b = (JButton) c;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (b.getModel().isRollover()) {
                    g2.setColor(new Color(115,116,124));
                } else {
                    g2.setColor(new Color(160,160,160));
                }
                g2.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), 30, 30);
                g2.dispose();
                super.paint(g, c);
            }
        });
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new menuGUI());
    }
}

