import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class login extends JFrame {

    private RoundedTextField emailField;
    private RoundedPasswordField passwordField;
    Color greyL = new Color(42,52,54);
    Color greyLlight = new Color(115,124,124);

    public login() {
        ImageIcon image = new ImageIcon("src/logoRoot.png");
        setIconImage(image.getImage());

        setTitle("Login");
        setSize(720, 720);
        setMinimumSize(new Dimension(400, 300));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(0, 0)); // Add gaps between components

        // Logo panel at the top
        JPanel logoPanel = new JPanel();
        logoPanel.setPreferredSize(new Dimension(200, 200));
        logoPanel.add(new JLabel(new ImageIcon(loadImage("src/lancasterLogo.png", 200, 200))));
        add(logoPanel, BorderLayout.NORTH);
        logoPanel.setBackground(greyL);

        // Input fields panel with GridBagLayout for better control
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBackground(greyL);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 30, 10, 30);

        emailField = new RoundedTextField(20);
        emailField.setHorizontalAlignment(JTextField.CENTER);
        emailField.setPlaceholder("EMAIL");
        setupPlaceholder(emailField, "EMAIL");
        inputPanel.add(emailField, gbc);

        passwordField = new RoundedPasswordField(20);
        passwordField.setPlaceholder("PASSWORD");
        passwordField.setHorizontalAlignment(JTextField.CENTER);
        setupPlaceholder(passwordField, "PASSWORD");
        inputPanel.add(passwordField, gbc);

        // Login Button
        JButton loginButton = new JButton("Login");
        customizeButtonLogin(loginButton);
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (checkCredentials(emailField.getText(), new String(passwordField.getPassword()))) {
                    openDashboard();
                    dispose(); // Close the login window
                } else {
                    JOptionPane.showMessageDialog(login.this, "Invalid credentials!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        inputPanel.add(loginButton, gbc);

        // Forgot Password Link
        JButton forgotPasswordButton = new JButton("Forgot Password?");
        forgotPasswordButton.setBorderPainted(false);
        forgotPasswordButton.setOpaque(false);
        forgotPasswordButton.setBackground(Color.WHITE);
        forgotPasswordButton.setForeground(Color.BLACK);
        forgotPasswordButton.addActionListener(e -> JOptionPane.showMessageDialog(login.this, "Password reset feature not implemented yet."));
        inputPanel.add(forgotPasswordButton, gbc);

        add(inputPanel, BorderLayout.CENTER);

        // Bottom panel
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(greyLlight);
        bottomPanel.setPreferredSize(new Dimension(100, 50));
        bottomPanel.add(new JLabel(new ImageIcon(loadImage("src/logoRoot.png", 50, 50))), BorderLayout.WEST);
        bottomPanel.add(new JSeparator(), BorderLayout.CENTER);
        JLabel copyrightLabel = new JLabel("© 2023 Root Solutions");
        bottomPanel.add(copyrightLabel, BorderLayout.EAST);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private Image loadImage(String path, int width, int height) {
        BufferedImage resizedImage = null;
        try {
            BufferedImage originalImage = ImageIO.read(new File(path));
            resizedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g2d = resizedImage.createGraphics();
            g2d.drawImage(originalImage, 0, 0, width, height, null);
            g2d.dispose();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resizedImage;
    }

    private void setupPlaceholder(JTextField field, String text) {
        field.setForeground(Color.GRAY);
        field.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (field.getText().equals(text)) {
                    field.setText("");
                    field.setForeground(Color.BLACK);
                }
            }

            public void focusLost(java.awt.event.FocusEvent evt) {
                if (field.getText().isEmpty()) {
                    field.setForeground(Color.GRAY);
                    field.setText(text);
                }
            }
        });
    }

    private boolean checkCredentials(String email, String password) {
        // Placeholder for checking credentials
        // Replace this with actual database checking logic
        return "tanimTheHotOne@onlyfans.com".equals(email) && "password123".equals(password);
    }

    private void openDashboard() {
        JFrame dashboardFrame = new JFrame("Dashboard");
        dashboardFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dashboardFrame.setSize(800, 600);
        dashboardFrame.add(new JLabel("Welcome to the Dashboard!", JLabel.CENTER), BorderLayout.CENTER);
        dashboardFrame.setVisible(true);
    }
    private void customizeButtonLogin(JButton button) {
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setFocusPainted(false);
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.repaint();
            }
        });
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                JButton b = (JButton) c;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (b.getModel().isRollover()) {
                    g2.setColor(new Color(115,116,124));
                } else {
                    g2.setColor(new Color(160,160,160));
                }
                g2.fillRoundRect(0, 0, b.getWidth(), b.getHeight(), 30, 30);
                g2.dispose();
                super.paint(g, c);
            }
        });
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new login());
    }
}

// Custom rounded text field
class RoundedTextField extends JTextField {
    private Shape shape;
    private String placeholder;

    public RoundedTextField(int size) {
        super(size);
        setOpaque(false); // As per your design
    }

    protected void paintComponent(Graphics g) {
        g.setColor(getBackground());
        g.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 15, 15);
        super.paintComponent(g);
    }

    protected void paintBorder(Graphics g) {
        g.setColor(getForeground());
        g.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 15, 15);
    }

    public boolean contains(int x, int y) {
        if (shape == null || !shape.getBounds().equals(getBounds())) {
            shape = new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 15, 15);
        }
        return shape.contains(x, y);
    }

    public void setPlaceholder(String text) {
        this.placeholder = text;
    }
}

// Custom rounded password field
class RoundedPasswordField extends JPasswordField {
    private Shape shape;
    private String placeholder;

    public RoundedPasswordField(int size) {
        super(size);
        setOpaque(false); // As per your design
    }

    protected void paintComponent(Graphics g) {
        g.setColor(getBackground());
        g.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 15, 15);
        super.paintComponent(g);
    }

    protected void paintBorder(Graphics g) {
        g.setColor(getForeground());
        g.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 15, 15);
    }

    public boolean contains(int x, int y) {
        if (shape == null || !shape.getBounds().equals(getBounds())) {
            shape = new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 15, 15);
        }
        return shape.contains(x, y);
    }

    public void setPlaceholder(String text) {
        this.placeholder = text;
    }
}
