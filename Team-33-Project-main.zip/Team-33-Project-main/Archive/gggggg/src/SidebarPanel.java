import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.net.URL;

public class SidebarPanel extends JPanel {

    private static final Color COLOR_WHITE = new Color(255, 255, 255);

    public SidebarPanel() {

        setBackground(new Color(115,124,124));
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        initializeComponents();
    }

    private void initializeComponents() {
        addLogo();
        addButtons();
    }

    private void addLogo() {
        JPanel logoPanel = new JPanel();
        logoPanel.setLayout(new BoxLayout(logoPanel, BoxLayout.X_AXIS));
        logoPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        logoPanel.setPreferredSize(new Dimension(100, 100));
        logoPanel.setBackground(Color.BLACK);

        try {
            URL imageUrl = getClass().getResource("/logoRoot.png"); // Ensure the path starts with a slash
            BufferedImage logoImage = ImageIO.read(imageUrl);
            Image scaledImage = logoImage.getScaledInstance(90, 90, Image.SCALE_SMOOTH);
            JLabel logoLabel = new JLabel(new ImageIcon(scaledImage));
            logoPanel.add(logoLabel);
            logoPanel.add(Box.createHorizontalGlue());
        } catch (IOException e) {
            System.err.println("Error loading logo image: " + e.getMessage());
            logoPanel.add(new JLabel("Logo not found"));
        }

        this.add(logoPanel);
        this.add(Box.createRigidArea(new Dimension(0, 20)));
    }

    private void addButtons() {
        this.add(createCenteredButton("Home", new Color(173, 216, 230)));
        this.add(createCenteredButton("Bookings", new Color(173, 216, 230)));
        this.add(createCenteredButton("Review Menu", new Color(173, 216, 230)));
        this.add(createCenteredButton("Staff Tracking", new Color(173, 216, 230)));
        this.add(createCenteredButton("Sales", new Color(173, 216, 230)));
        this.add(createCenteredButton("Order Ingredients", new Color(173, 216, 230)));
    }

    private JButton createCenteredButton(String text, Color hoverColor) {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, button.getMinimumSize().height));
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setForeground(Color.WHITE);
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setContentAreaFilled(true);
                button.setBackground(hoverColor);
            }
            public void mouseExited(MouseEvent e) {
                button.setContentAreaFilled(false);
            }
        });
        return button;
    }
}
