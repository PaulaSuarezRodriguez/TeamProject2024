import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class SommelierUI extends JFrame {

    private DefaultTableModel tableModel;
    private JTable wineTable;
    private JTextField txtWineID;
    private JTextField txtName;
    private JTextField txtYear;
    private JTextField txtQuantity;

    public SommelierUI() {
        setTitle("Sommelier Book");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        initUI();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void initUI() {
        // Initialize the table with a DefaultTableModel
        tableModel = new DefaultTableModel(new String[]{"Wine ID", "Name", "Year", "Quantity"}, 0);
        wineTable = new JTable(tableModel);
        fetchWinesFromDatabase(); // Load data from database

        JScrollPane scrollPane = new JScrollPane(wineTable);
        wineTable.setFillsViewportHeight(true);

        // Setup layout and add components
        this.setLayout(new BorderLayout());
        this.add(scrollPane, BorderLayout.CENTER);

        // Add button panel at the bottom or where appropriate
        JPanel buttonPanel = new JPanel();
        JButton addButton = new JButton("Add Wine");
        addButton.addActionListener(e -> addWine());
        JButton deleteButton = new JButton("Delete Selected Wine");
        deleteButton.addActionListener(e -> deleteSelectedWine());

        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        this.add(buttonPanel, BorderLayout.SOUTH);
    }

    private void fetchWinesFromDatabase() {
        try {
            Connection conn = JDBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM SommelierBook");

            // Reset table model
            tableModel.setRowCount(0);

            while (rs.next()) {
                // Assuming your table columns match these data types
                int wineID = rs.getInt("wine_ID");
                String name = rs.getString("Name");
                int year = rs.getInt("Year");
                int quantity = rs.getInt("StockQuantity");
                tableModel.addRow(new Object[]{wineID, name, year, quantity});
            }

            JDBConnection.closeResult(rs);
            JDBConnection.closeStatement(stmt);
            JDBConnection.closeConnection(conn);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    private void addWine() {
        try {
            int wineID = Integer.parseInt(txtWineID.getText());
            String name = txtName.getText();
            int year = Integer.parseInt(txtYear.getText());
            int quantity = Integer.parseInt(txtQuantity.getText());

            SommelierBook sommelierBook = new SommelierBook(wineID, name, year, quantity);
            sommelierBook.addWine(wineID, name, year, quantity);

            // Refresh table
            fetchWinesFromDatabase();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for Wine ID, Year, and Quantity.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void deleteSelectedWine() {
        int selectedRow = wineTable.getSelectedRow();
        if (selectedRow >= 0) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete the selected wine?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                int wineID = (int) wineTable.getValueAt(selectedRow, 0);
                SommelierBook sommelierBook = new SommelierBook(wineID, "", 0, 0);
                sommelierBook.deleteWine(wineID);

                // Refresh table
                fetchWinesFromDatabase();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a wine to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(SommelierUI::new);
    }
}

//shows a table and can delete from a table now just add how u can edit and add.