import java.util.List;

public class SupplierIngredients {

    private List<String> ingredients;

    public SupplierIngredients(List<String> ingredients) {
        this.ingredients = ingredients;
    }

    //setters and getters


    public List<String> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<String> ingredients) {
        this.ingredients = ingredients;
    }
}
