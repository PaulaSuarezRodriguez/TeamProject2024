import java.util.List;

public class KitchenServiceSender implements IKitchenSender{


    @Override
    public void sendUpdatedMenus(FrontOfHouseMenu menus) {

    }

    @Override
    public void sendIngredientsList(SupplierIngredients ingredients) {

    }
}
