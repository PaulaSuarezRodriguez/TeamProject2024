import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FrontOfHouseReciever implements IFrontOfHouseReciever {

    @Override
    public int getDailyBookingsCount() {
        // Implementation to return the count of daily bookings
        return 0; // Example count
    }

    @Override
    public double getTotalRevenue() {
        // Implementation to return the total revenue
        return 0.0; // Example revenue
    }

    @Override
    public Map<Integer,Integer> getOrderDetails(){

        return null;
    }

    @Override
    public Map<Integer, LocalDateTime> getTableDetails() {
        return new HashMap<>(getTableDetails());
    }
}
