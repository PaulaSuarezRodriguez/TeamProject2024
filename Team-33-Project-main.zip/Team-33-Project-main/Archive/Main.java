public class Main {
    public static void main(String[] args) {
        DBWriter dataWriter = new DBWriter();
        DBReader dataReader = new DBReader();

        // Call methods to write and read data
        // Below is just a sample for testing.
        String insertQuery = "INSERT INTO Ingredient (Ingredient_ID, name, Price) VALUES (3, 'chili', 2.5)";
        dataWriter.insertData(insertQuery);

        dataReader.readData("SELECT * FROM Ingredient");
    }
}