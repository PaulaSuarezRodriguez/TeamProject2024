import java.util.List;

public class Dish {
    private int id;
    private String name;
    private List<String> ingredients;
    private List<String> allergenInfo;

    public Dish(int id, String name, List<String> ingredients, List<String> allergenInfo) {
        this.id = id;
        this.name = name;
        this.ingredients = ingredients;
        this.allergenInfo = allergenInfo;
    }

    // Getters and Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<String> ingredients) {
        this.ingredients = ingredients;
    }

    public List<String> getAllergens() {
        return allergenInfo;
    }

    public void setAllergens(List<String> allergens) {
        this.allergenInfo = allergenInfo;
    }
}
