import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface IFrontOfHouseReciever {
    int getDailyBookingsCount();
    double getTotalRevenue();
    Map<Integer, Integer> getOrderDetails();

    Map<Integer, LocalDateTime> getTableDetails(); //covers per half hour. We need the table size and the time its in
}