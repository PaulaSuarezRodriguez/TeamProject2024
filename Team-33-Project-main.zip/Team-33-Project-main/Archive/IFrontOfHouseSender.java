import java.time.DayOfWeek;
import java.util.List;
import java.util.Map;

public interface IFrontOfHouseSender {

    void sendUpdatedMenus(FrontOfHouseMenu menus);
    void sendWeeklyAverageBookings(Map<DayOfWeek, Integer> averageBookings);


}
