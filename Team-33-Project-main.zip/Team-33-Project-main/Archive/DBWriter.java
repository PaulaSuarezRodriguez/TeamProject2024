import java.sql.*;
public class DBWriter {
    public void insertData(String query){
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try{
            connection = JDBConnection.getConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.executeUpdate();
        } catch (SQLException e){
            e.printStackTrace();
        } finally {
            JDBConnection.closeStatement(preparedStatement);
            JDBConnection.closeConnection(connection);
        }
        }



}
