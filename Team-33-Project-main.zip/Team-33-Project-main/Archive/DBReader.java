import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBReader {
    public void readData(String query){
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try{
            connection = JDBConnection.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery(query);

            while(resultSet.next()){
                System.out.println(resultSet.getDouble(1)+ " " + resultSet.getString(2)+ " " + resultSet.getDouble(3));
            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            JDBConnection.closeConnection(connection);
            JDBConnection.closeStatement(statement);
            JDBConnection.closeResult(resultSet);
        }
    }
}
