import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class StaffInfo {
    private int staff_ID, restaurantID;
    private String name, phoneNumber, email, address, role, status;
    Date holidayStartDate, holidayEndDate;
    //  FOREIGN KEY (RestaurantID) REFERENCES Restaurant(RestaurantID) ????

    public StaffInfo(int staff_ID, String name, String role, Date holidayStartDate, Date holidayEndDate){
        this.staff_ID = staff_ID;
        this.name = name;
        this.role = role;
        this.holidayStartDate = holidayStartDate;
        this.holidayEndDate = holidayEndDate;
    }

    //Getters
    public int getStaffID() {
        return staff_ID;
    }
    public String getName() {
        return name;
    }
    public String getRole() {return role;}
    public Date getHolidayStartDate() {return holidayStartDate;}
    public Date getHolidayEndDate() {return holidayEndDate;}

    //Setters
    public void setStaffID(int staff_ID) {this.staff_ID = staff_ID;}
    public void setName(String name) {this.name = name;}
    public void setPhoneNumber(String phoneNumber) {this.phoneNumber = phoneNumber;}
    public void setRole(String role) {this.role = role;}
    public Date setHolidayStartDate(Date holidayStartDate) {return holidayStartDate;}
    public Date setHolidayEndDate(Date holidayStartDate) {return holidayEndDate;}

    //add staff member
    public void addStaffMember(int staff_ID, String name, String role, Date holidayStartDate, Date holidayEndDate){
        Connection connection = null;
        PreparedStatement preparedStatementRestaurant = null;
        PreparedStatement preparedStatementStaff = null;
        ResultSet resultSetRestaurant = null;

        try {
            //Establish connection to the DB
            connection = JDBConnection.getConnection();

            //Prepare SQL statement of parent table
            String queryStaff = "INSERT INTO StaffInfo (staff_ID, name, role, holidayStartDate, holidayEndDate) VALUES (?, ?, ?, ?, ?)";
            preparedStatementStaff = connection.prepareStatement(queryStaff);
            preparedStatementStaff.setInt(1, staff_ID);
            preparedStatementStaff.setString(2, name);
            preparedStatementStaff.setString(3, role);
            preparedStatementStaff.setDate(4, holidayStartDate);
            preparedStatementStaff.setDate(5, holidayEndDate);

            //Execute update parent table
            preparedStatementStaff.executeUpdate();
            System.out.println("Staff member information added successfully.");



        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JDBConnection.closeStatement(preparedStatementRestaurant);
            JDBConnection.closeStatement(preparedStatementStaff);
            JDBConnection.closeResult(resultSetRestaurant);
            JDBConnection.closeConnection(connection);
        }
    }

    //delete staff member
    public void deleteStaffMember(int staff_ID){
        Connection connection = null;
        PreparedStatement preparedStatementStaff = null;
        PreparedStatement preparedStatementStaffContract = null;

        try {
            //Establish connection
            connection = JDBConnection.getConnection();

            //Prepare SQL statement to delete from parent table
            String queryStaff = "DELETE FROM StaffInfo WHERE staff_ID = ? ";
            preparedStatementStaff = connection.prepareStatement(queryStaff);
            preparedStatementStaff.setInt(1, staff_ID);

            //Execute deletion in parent table
            int rowsAffected = preparedStatementStaff.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Staff member with ID " + staff_ID + " deleted successfully.");
            } else {
                System.out.println("No staff member found with ID " + staff_ID + ". No rows deleted.");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            JDBConnection.closeConnection(connection);
            JDBConnection.closeStatement(preparedStatementStaffContract);
            JDBConnection.closeStatement(preparedStatementStaff);
        }
    }

    public void readStaffMember(){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try{
            //Establish a connection to DB
            connection = JDBConnection.getConnection();

            //Prepare the SQL query
            String query = "SELECT * FROM Staff";
            preparedStatement = connection.prepareStatement(query);

            //Execute
            resultSet = preparedStatement.executeQuery();

            while(resultSet.next()){
                System.out.println("Staff member ID: " + resultSet.getInt(1)
                        + ", Name: " + resultSet.getString(2)
                        + ", Role: " + resultSet.getString(3)
                        + ", Holiday start date: " + resultSet.getDate(4)
                        + ", Holiday end date: " + resultSet.getDate(5));
            }
        } catch (SQLException e){
            e.printStackTrace();
        } finally {
            JDBConnection.closeConnection(connection);
            JDBConnection.closeStatement(preparedStatement);
            JDBConnection.closeResult(resultSet);
        }
    }

    public static void main(String[] args) {
        //Sample data
        int staffID = 6666;
        String name = "Anothername Anothersurname";
        String role = "Waiter";
        Date holidayStartDate = java.sql.Date.valueOf("2024-09-09");
        Date holidayEndDate = java.sql.Date.valueOf("2024-09-09");


        //Create an instance of the class
        StaffInfo staffMember = new StaffInfo(staffID, name, role, holidayStartDate, holidayEndDate);

        //Deletes staff member with ID specified by number passed as argument
        // staffMember.deleteStaffMember(staffID);

        //Adds to table
     //   staffMember.addStaffMember(staffID, name, role, holidayStartDate, holidayEndDate);

        //Prints the table "Staff". Reads all entries/ info on all staff members
        //  staffMember.readStaffMember();

    }
}

