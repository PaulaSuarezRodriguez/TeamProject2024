public interface IKitchenReciever {
    Menu getCurrentMenu();
    Dish getDishDetails(int dishId);
}
