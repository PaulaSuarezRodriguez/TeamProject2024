import java.math.BigDecimal;

public class FrontOfHouseMenu {

    private String name;
    private String description;
    private String allergenInfo;
    private BigDecimal price;

    // Constructor
    public FrontOfHouseMenu(String name, BigDecimal price, String allergenInfo, String description) {
        this.name = name;
        this.price = price;
        this.allergenInfo = allergenInfo;
        this.description = description;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String title) {
        this.name = title;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getAllergenInfo() {
        return allergenInfo;
    }

    public void setAllergenInfo(String allergenInfo) {
        this.allergenInfo = allergenInfo;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
